import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash,randomUUID} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {runOwnedWindowsChild} from './owned-windows-child.mjs';
const work=fileURLToPath(new URL('./',import.meta.url)),repo='C:/Users/just_/lesters-arcade-wt/visual-overhaul-200',marker='C:/Users/just_/lesters-arcade-wt/.locks/heavy.lock',out=path.join(work,'achievement-rarity-green-01');
const files=['apps/portal/src/achievements/rarity.mjs','server/neon/achievement-stats.mjs','api/achievements/stats.mjs','tests/achievement-rarity.test.mjs','tests/achievement-rarity-query.test.mjs','tests/achievement-rarity-api.test.mjs'];
const pin=file=>({file,sha256:createHash('sha256').update(fs.readFileSync(file)).digest('hex')});
const protectedFiles=['apps/portal/src/achievements/index.mjs','apps/portal/src/achievements/hmh.mjs','apps/portal/src/achievements/chikun.mjs','apps/portal/src/achievements/stacked.mjs','server/settle/store.mjs','server/neon/queries.mjs','server/neon/migrations.mjs','server/verify/chikun.mjs','server/verify/hmh.mjs','server/verify/stacked.mjs'];
assert.equal(fs.existsSync(out),false);assert.equal(fs.existsSync(marker),false);const before=[...files,...protectedFiles].map(file=>pin(path.join(repo,file))),token='achievement-rarity-green-'+randomUUID();fs.mkdirSync(marker);fs.writeFileSync(path.join(marker,'owner.json'),JSON.stringify({owner:'/root',token,task:'Actual read-only rarity SQL/API GREEN with existing local PGlite'}));fs.mkdirSync(out);
const report={scope:'Fourteen rarity/SQL/production-adapter cases on in-memory PGlite only; no production DB/network, earning/rules/settlement change',before,phases:[]};let closed=true;
async function run(name,args){closed=false;const command=await runOwnedWindowsChild('C:/Program Files/nodejs/node.exe',args,{cwd:repo,watchdogMs:30000,maxOutputBytes:1024*1024});closed=command.childClosureConfirmed;report.phases.push({name,command});assert.ok(closed);assert.ok(command.normalExit,name+' failed; preserve actual output');return command;}
try{
 const command=await run('actual-sql-api-and-rarity',['--test','--test-reporter=tap','--test-concurrency=1',...files.filter(file=>file.startsWith('tests/'))]);report.counts=Object.fromEntries(['tests','pass','fail','skipped','cancelled'].map(key=>[key,Number(command.stdout.match(new RegExp('^# '+key+' (\\d+)$','m'))?.[1])]));assert.deepEqual(report.counts,{tests:14,pass:14,fail:0,skipped:0,cancelled:0});
 for(const file of files)await run('parse-'+file,['--check',file]);report.passed=true;
}catch(error){report.failure=error.stack;process.exitCode=1;}finally{report.after=before.map(value=>pin(value.file));assert.deepEqual(report.after,before);report.childrenClosed=closed;if(closed){assert.equal(JSON.parse(fs.readFileSync(path.join(marker,'owner.json'))).token,token);fs.unlinkSync(path.join(marker,'owner.json'));fs.rmdirSync(marker);report.markerReleased=true;}fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({passed:report.passed,counts:report.counts,markerReleased:report.markerReleased,failure:report.failure??null}));}
