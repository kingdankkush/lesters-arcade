import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash,randomUUID} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {runOwnedWindowsChild} from './owned-windows-child.mjs';
const work=fileURLToPath(new URL('./',import.meta.url)),repo='C:/Users/just_/lesters-arcade-wt/visual-overhaul-200',marker='C:/Users/just_/lesters-arcade-wt/.locks/heavy.lock';
const target='tests/achievement-rarity.test.mjs',feature=path.join(repo,'apps/portal/src/achievements/rarity.mjs'),out=path.join(work,'achievement-rarity-red-01');
const sha=file=>createHash('sha256').update(fs.readFileSync(file)).digest('hex');
assert.equal(fs.existsSync(feature),false);assert.equal(fs.existsSync(out),false);assert.equal(fs.existsSync(marker),false);
const files=[path.join(repo,target),fileURLToPath(import.meta.url),path.join(work,'owned-windows-child.mjs')],before=files.map(file=>({file,sha256:sha(file)}));
const token='achievement-rarity-red-'+randomUUID();fs.mkdirSync(marker);fs.writeFileSync(path.join(marker,'owner.json'),JSON.stringify({owner:'/root',token,task:'Small pure achievement rarity behavior RED'}));fs.mkdirSync(out);
const report={scope:'Eight behavior requirements against absent pure presentation module; no DB/network/runtime/gameplay changes',before,featureAbsentBefore:true};let closed=true;
try{closed=false;report.command=await runOwnedWindowsChild('C:/Program Files/nodejs/node.exe',['--test','--test-reporter=tap',target],{cwd:repo,watchdogMs:20000});closed=report.command.childClosureConfirmed;report.counts=Object.fromEntries(['tests','pass','fail','skipped','cancelled'].map(key=>[key,Number(report.command.stdout.match(new RegExp('^# '+key+' (\\d+)$','m'))?.[1])]));assert.deepEqual(report.counts,{tests:8,pass:0,fail:8,skipped:0,cancelled:0});assert.equal(report.command.exitCode,1);assert.ok(closed&&!report.command.watchdogTriggered);assert.equal(fs.existsSync(feature),false);report.passed=true;}catch(error){report.failure=error.stack;process.exitCode=1;}finally{report.after=files.map(file=>({file,sha256:sha(file)}));assert.deepEqual(report.after,before);fs.writeFileSync(path.join(out,'test-source.mjs.txt'),fs.readFileSync(path.join(repo,target)));report.childrenClosed=closed;if(closed){assert.equal(JSON.parse(fs.readFileSync(path.join(marker,'owner.json'))).token,token);fs.unlinkSync(path.join(marker,'owner.json'));fs.rmdirSync(marker);report.markerReleased=true;}fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({passed:report.passed,counts:report.counts,markerReleased:report.markerReleased}));}
