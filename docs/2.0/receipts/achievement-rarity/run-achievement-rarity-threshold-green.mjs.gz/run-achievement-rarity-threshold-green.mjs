import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash,randomUUID} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {runOwnedWindowsChild} from './owned-windows-child.mjs';
const work=fileURLToPath(new URL('./',import.meta.url)),repo='C:/Users/just_/lesters-arcade-wt/visual-overhaul-200',marker='C:/Users/just_/lesters-arcade-wt/.locks/heavy.lock',out=path.join(work,'achievement-rarity-threshold-green-01');
const files=['apps/portal/src/achievements/rarity.mjs','tests/achievement-rarity.test.mjs','tests/achievement-rarity-query.test.mjs','tests/achievement-rarity-api.test.mjs'];
const pin=file=>({file,sha256:createHash('sha256').update(fs.readFileSync(file)).digest('hex')});
assert.equal(fs.existsSync(out),false);assert.equal(fs.existsSync(marker),false);for(const file of['server/neon/achievement-stats.mjs','api/achievements/stats.mjs'])assert.equal(fs.existsSync(path.join(repo,file)),false);
const before=files.map(file=>pin(path.join(repo,file))),token='achievement-rarity-threshold-green-'+randomUUID();fs.mkdirSync(marker);fs.writeFileSync(path.join(marker,'owner.json'),JSON.stringify({owner:'/root',token,task:'Pure thresholds GREEN, actual aggregate/API RED'}));fs.mkdirSync(out);
const report={scope:'Eight pure threshold behavior cases and six aggregate/API requirements before implementation; no production DB/network',before,phases:[]};let closed=true;
const counts=command=>Object.fromEntries(['tests','pass','fail','skipped','cancelled'].map(key=>[key,Number(command.stdout.match(new RegExp('^# '+key+' (\\d+)$','m'))?.[1])]));
async function run(name,args,cwd,expected){closed=false;const command=await runOwnedWindowsChild('C:/Program Files/nodejs/node.exe',args,{cwd,env:{...process.env},watchdogMs:20000});closed=command.childClosureConfirmed;report.phases.push({name,command,counts:counts(command)});assert.ok(closed&&!command.watchdogTriggered);assert.equal(command.exitCode,expected);return command;}
try{
 await run('threshold-green-and-aggregate-api-red',['--test','--test-reporter=tap','--test-concurrency=1',...files.filter(file=>file.startsWith('tests/'))],repo,1);assert.deepEqual(report.phases[0].counts,{tests:14,pass:8,fail:6,skipped:0,cancelled:0});
 const copy=path.join(out,'no-git-no-modules-copy');for(const file of files.slice(0,2)){const destination=path.join(copy,file);fs.mkdirSync(path.dirname(destination),{recursive:true});fs.writeFileSync(destination,fs.readFileSync(path.join(repo,file)));}
 assert.equal(fs.existsSync(path.join(copy,'.git')),false);assert.equal(fs.existsSync(path.join(copy,'node_modules')),false);
 await run('exact-pure-copy-no-git-no-modules',['--test','--test-reporter=tap','tests/achievement-rarity.test.mjs'],copy,0);assert.deepEqual(report.phases[1].counts,{tests:8,pass:8,fail:0,skipped:0,cancelled:0});report.passed=true;
}catch(error){report.failure=error.stack;process.exitCode=1;}finally{report.after=files.map(file=>pin(path.join(repo,file)));assert.deepEqual(report.after,before);report.childrenClosed=closed;if(closed){assert.equal(JSON.parse(fs.readFileSync(path.join(marker,'owner.json'))).token,token);fs.unlinkSync(path.join(marker,'owner.json'));fs.rmdirSync(marker);report.markerReleased=true;}fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({passed:report.passed,phases:report.phases.map(value=>({name:value.name,counts:value.counts,exitCode:value.command.exitCode})),markerReleased:report.markerReleased,failure:report.failure??null}));}
