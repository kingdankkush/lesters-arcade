from pathlib import Path
import json,hashlib
w=Path(__file__).parent;r=Path('C:/Users/just_/lesters-arcade-wt/visual-overhaul-200');origin=Path('C:/Users/just_/lesters-arcade-wt/200-world-w0')
m=json.loads((w/'world-w3a-green-bindings.json').read_text(encoding='utf-8'))
rows=[]
for rel,pin in m['sources'].items():
 original=(origin/rel).read_bytes();actual=(r/rel).read_bytes();expected=pin['sha256']
 assert hashlib.sha256(original).hexdigest()==expected,rel
 assert actual.replace(b'\r\n',b'\n')==original.replace(b'\r\n',b'\n'),rel
 rows.append({'path':rel,'sourceSha256':expected,'rootSha256':hashlib.sha256(actual).hexdigest(),'checkoutLineEndingDifferenceOnly':actual!=original})
out={'scope':'Exact gathered W3a source/fixture closure, permitting observed CRLF checkout conversions only; not a new test execution. Original source and identical isolated groups each passed150.','passed':True,'files':rows,'count':len(rows)}
(w/'world-w3a-root-gather.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'passed':True,'files':len(rows),'lineEndingConversions':sum(row['checkoutLineEndingDifferenceOnly'] for row in rows)}))
