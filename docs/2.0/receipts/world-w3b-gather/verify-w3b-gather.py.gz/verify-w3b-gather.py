from pathlib import Path
import hashlib,json
w=Path(__file__).parent;r=Path(r'C:\Users\just_\lesters-arcade-wt\visual-overhaul-200');lane=Path(r'C:\Users\just_\lesters-arcade-wt\200-world-w0')
b=json.loads((w/'world-w3b-green02-bindings.json').read_text());rows=[]
for relative,pin in b['sources'].items():
    source=(lane/relative).read_bytes();root=(r/relative).read_bytes()
    assert hashlib.sha256(source).hexdigest()==pin['sha256'],relative
    assert source.replace(b'\r\n',b'\n')==root.replace(b'\r\n',b'\n'),relative
    rows.append({'path':relative,'sourceSha256':pin['sha256'],'rootSha256':hashlib.sha256(root).hexdigest(),'checkoutLineEndingDifferenceOnly':source!=root})
for relative,digest in b['protectedFiles'].items():assert hashlib.sha256((r/relative).read_bytes()).hexdigest()==digest,relative
report={'passed':True,'scope':'Gathered source is identical except documented Git checkout CRLF conversion. Initial strict-byte proof stopped at greybox-world-v1 before source execution; commit gathering completed. This does not claim a new test run.','files':rows,'protectedFiles':b['protectedFiles'],'count':len(rows)}
(w/'world-w3b-root-gather.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'files':len(rows),'authorityPins':len(b['protectedFiles']),'lineEndingOnly':[x['path'] for x in rows if x['checkoutLineEndingDifferenceOnly']]}))
