import fs from 'node:fs';import path from 'node:path';import http from 'node:http';import assert from 'node:assert/strict';import {createHash} from 'node:crypto';import {gunzipSync} from 'node:zlib';import {fileURLToPath,pathToFileURL} from 'node:url';
const work=fileURLToPath(new URL('./',import.meta.url)),repo='C:/Users/just_/lesters-arcade-wt/visual-overhaul-200',portal=path.join(repo,'apps/portal'),out=path.join(work,'stacked-daily-browser-01'),token=process.argv[2];
assert.equal(JSON.parse(fs.readFileSync('C:/Users/just_/lesters-arcade-wt/.locks/heavy.lock/owner.json')).token,token);assert.equal(fs.existsSync(out),false);fs.mkdirSync(out);
const {chromium}=await import(pathToFileURL(path.join(repo,'benchmarks/hmh-engine-bakeoff/node_modules/playwright/index.mjs')));
const hash=b=>createHash('sha256').update(b).digest('hex'),report={passed:false,cases:[],captures:[],metrics:[],pageErrors:[],cleanupErrors:[],served:{},scope:'Actual locally built Windows Chrome; phone dimensions/touch are emulated. No physical phone, production or Ranked acceptance.'};
const save=()=>fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2)+'\n');
let server,browserServer,browser,chromeClosed=false,chromeClosePromise,origin,lastPage;
const mime={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.json':'application/json','.css':'text/css','.svg':'image/svg+xml','.png':'image/png','.webp':'image/webp','.mp3':'audio/mpeg','.woff2':'font/woff2'};
async function bounded(name,fn){let timer;try{await Promise.race([fn(),new Promise((_,reject)=>timer=setTimeout(()=>reject(Error(name+' timeout')),5000))]);return true;}catch(e){report.cleanupErrors.push({name,error:e.message});return false;}finally{clearTimeout(timer);}}

async function enter(context,query='?stackedDaily=daily-v1',{daily=true}={}) {
 const page=await context.newPage();lastPage=page;page.setDefaultTimeout(8000);page.on('pageerror',e=>report.pageErrors.push(e.message));
 await page.goto(origin+query,{waitUntil:'domcontentloaded'});await page.locator('#officialGuestEnterButton').click();await page.locator('.official-cabinet-card').filter({hasText:'STACKED'}).click();
 if(daily){await page.locator('#stackedStartLevel').selectOption('15');await page.locator('#stackedDailyChoice').check();assert.equal(await page.locator('#stackedStartLevel').isDisabled(),true);}
 else assert.equal(await page.locator('#stackedDailyChoice').count(),0);
 await page.locator('#officialFreeModeButton').click();const f=page.frameLocator('iframe[src*="/stacked/index.html"]');await f.locator('#stackedStage[data-assets-ready="true"]').waitFor();
 const actual=page.frames().find(f=>f.url().includes('/stacked/index.html'));return{page,f,actual};
}
async function observe(context,{storageFail=false,holdWorker=false}={}) {
 await context.addInitScript(({storageFail,holdWorker})=>{
  const NativeDate=Date;globalThis.__qaDailyNow=NativeDate.parse('2026-09-30T23:59:59.000Z');
  globalThis.Date=class extends NativeDate { constructor(...args){super(...(args.length?args:[globalThis.__qaDailyNow]));}static now(){return globalThis.__qaDailyNow;} };
  globalThis.__qaDailyInits=[];globalThis.__qaDailyWorkers=[];
  const NativeChannel=MessageChannel;globalThis.MessageChannel=class extends NativeChannel{constructor(){super();const send=this.port1.postMessage.bind(this.port1);this.port1.postMessage=(message,...rest)=>{if(message?.type==='portal:init')globalThis.__qaDailyInits.push(structuredClone(message.payload));send(message,...rest);};}};
  const NativeWorker=Worker;globalThis.Worker=class extends NativeWorker{postMessage(message,...rest){if(message?.requestId==='verify-1'){const item={seed:message.expectedSeed,config:message.config};globalThis.__qaDailyWorkers.push(item);this.addEventListener('message',event=>{item.response=event.data;},{once:true});if(holdWorker)return;}super.postMessage(message,...rest);}};
  if(storageFail){const set=Storage.prototype.setItem;Storage.prototype.setItem=function(key,value){if(key==='stacked-daily-best-v1')throw new DOMException('Daily storage unavailable','QuotaExceededError');return set.call(this,key,value);};}
 },{storageFail,holdWorker});
}
async function capture(page,f,name){
 await f.locator('.panel').evaluate(p=>{p.scrollTop=0;});
 const m=await f.locator('#dailyRunInfo').evaluate(e=>{const r=e.getBoundingClientRect(),p=e.closest('.panel').getBoundingClientRect();return{width:innerWidth,scroll:document.documentElement.scrollWidth,left:r.left,right:r.right,panelLeft:p.left,panelRight:p.right,date:e.textContent,buttons:[...document.querySelectorAll('.result-actions button')].filter(b=>b.getClientRects().length).map(b=>({label:b.textContent,w:b.getBoundingClientRect().width,h:b.getBoundingClientRect().height}))};});
 assert.ok(m.scroll<=m.width&&m.left>=0&&m.right<=m.width);assert.ok(m.buttons.every(b=>b.w>=44&&b.h>=44));report.metrics.push({name,...m});
 const file=path.join(out,name+'.png');await page.screenshot({path:file});report.captures.push({name,file,sha256:hash(fs.readFileSync(file))});
}
async function finishRun(page,f,{touch=false,pending=false,undo=false}={}){
 await f.locator('#continueButton').click();await f.locator('#gameOverlay').waitFor({state:'hidden'});
 if(undo){await page.keyboard.down('Space');await page.waitForTimeout(75);await page.keyboard.up('Space');await page.waitForTimeout(75);await f.locator('#undoButton').click();}
 for(let i=0;i<32;i++){
  if(await f.locator('#restartButton').isVisible())break;
  if(touch)await f.locator('[data-action="hardDrop"]').tap();else{await page.keyboard.down('Space');await page.waitForTimeout(65);await page.keyboard.up('Space');}
  await page.waitForTimeout(75);
 }
 await f.locator('#restartButton').waitFor();
 if(!pending)await f.locator('#restartButton:enabled').waitFor();
}
async function retry(page,f){await f.locator('#restartButton').click();await f.locator('#continueButton').waitFor();await f.locator('#stackedStage[data-assets-ready="true"]').waitFor();await f.locator('#continueButton:enabled').waitFor();}
try{
 server=http.createServer((req,res)=>{try{const url=new URL(req.url,'http://127.0.0.1');if(url.pathname==='/favicon.ico'){res.writeHead(204);res.end();return;}let file=path.resolve(portal,'.'+decodeURIComponent(url.pathname));assert.ok(file===portal||file.startsWith(portal+path.sep));if(fs.statSync(file).isDirectory())file=path.join(file,'index.html');const bytes=fs.readFileSync(file);report.served[path.relative(repo,file).replaceAll('\\','/')]=hash(bytes);res.setHeader('Cache-Control','no-store');res.setHeader('Content-Type',mime[path.extname(file)]??'application/octet-stream');res.end(bytes);}catch{res.writeHead(404);res.end();}});
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});origin='http://127.0.0.1:'+server.address().port;report.origin=origin;
 browserServer=await chromium.launchServer({executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true});report.chromePid=browserServer.process().pid;chromeClosePromise=new Promise(resolve=>browserServer.process().once('close',(code,signal)=>{chromeClosed=true;report.chromeClose={code,signal};resolve();}));browser=await chromium.connect(browserServer.wsEndpoint());report.version=browser.version();

 const ctx=await browser.newContext({viewport:{width:1440,height:1000},serviceWorkers:'block'});await observe(ctx);
 const {page,f}=await enter(ctx);assert.equal(await f.locator('#dailyRunDate').textContent(),'2026-09-30 UTC');
 const init=await page.evaluate(()=>__qaDailyInits.at(-1));assert.equal(init.settings.startLevel,1);assert.equal(init.session.seed,1885307033);assert.equal(init.dailyChallenge.bestScore,null);report.initial=init;
 await capture(page,f,'desktop-daily-start');const before=await page.evaluate(()=>({...localStorage}));
 await finishRun(page,f);assert.match(await f.locator('#overlayCopy').textContent(),/First daily best/);await capture(page,f,'desktop-daily-result');
 const after=await page.evaluate(()=>({...localStorage}));report.changedStorage=Object.keys(after).filter(k=>after[k]!==before[k]);assert.ok(report.changedStorage.every(k=>['stacked-free-medals-v1','stacked-daily-best-v1'].includes(k)));assert.ok(after['stacked-daily-best-v1']);
 const first=JSON.parse(after['stacked-daily-best-v1']).records[0];assert.equal(first.seed,1885307033);assert.equal(first.dayKey,'2026-09-30');report.cases.push('actual Free daily at level1, worker replay and local best only');
 await retry(page,f);assert.equal((await page.evaluate(()=>__qaDailyInits.at(-1))).dailyChallenge.bestScore,first.score);assert.equal(await f.locator('#dailyRunDate').textContent(),'2026-09-30 UTC');report.cases.push('same-day retry keeps seed and shows saved best');
 await page.evaluate(()=>{__qaDailyNow=Date.parse('2026-10-01T00:00:01Z');});await finishRun(page,f);assert.match(await f.locator('#overlayCopy').textContent(),/2026-09-30 UTC/);report.cases.push('run across midnight stays on its issued day');
 await retry(page,f);const tomorrow=await page.evaluate(()=>__qaDailyInits.at(-1));assert.equal(tomorrow.dailyChallenge.dayKey,'2026-10-01');assert.equal(tomorrow.session.seed,2534331135);assert.equal(tomorrow.dailyChallenge.bestScore,null);report.cases.push('retry after midnight starts new UTC day');
 report.workers=await page.evaluate(()=>__qaDailyWorkers);assert.equal(report.workers.length,2);for(const worker of report.workers){assert.equal(worker.config.startLevel,1);assert.equal(worker.seed,1885307033);assert.equal(worker.response.ok,true);assert.equal(worker.response.tuple.seed,1885307033);}await ctx.close();
 for(const[width,height,touch]of[[414,896,true],[320,900,false],[768,1000,false],[1024,1000,false]]){
  const c=await browser.newContext({viewport:{width,height},deviceScaleFactor:touch?3:1,hasTouch:touch,isMobile:touch,reducedMotion:'reduce',serviceWorkers:'block'});await observe(c);const{page:p,f:frame}=await enter(c);await capture(p,frame,'daily-layout-'+width);
  if(touch){await finishRun(p,frame,{touch:true});assert.match(await frame.locator('#overlayCopy').textContent(),/First daily best/);await capture(p,frame,'phone-daily-result');report.cases.push('real touch controls finish daily and verify replay');}
  report.cases.push('contained daily UI '+width);await c.close();
 }
 for(const query of['','?stackedDaily=bad','?stackedDaily=daily-v1&stackedDaily=daily-v1']){const c=await browser.newContext({serviceWorkers:'block'});const{f:frame}=await enter(c,query,{daily:false});assert.equal(await frame.locator('#dailyRunInfo').isVisible(),false);report.cases.push('daily off '+(query||'default'));await c.close();}
 const unavailable=await browser.newContext({serviceWorkers:'block'});await observe(unavailable,{storageFail:true});const noStore=await enter(unavailable);await finishRun(noStore.page,noStore.f);assert.match(await noStore.f.locator('#overlayCopy').textContent(),/storage is unavailable/);assert.equal(await noStore.page.evaluate(()=>localStorage.getItem('stacked-daily-best-v1')),null);report.cases.push('storage failure preserves completed game and retry');await unavailable.close();
 const assisted=await browser.newContext({serviceWorkers:'block'});await observe(assisted);const a=await enter(assisted);await finishRun(a.page,a.f,{undo:true});assert.match(await a.f.locator('#overlayCopy').textContent(),/Assisted/);assert.equal(await a.page.evaluate(()=>localStorage.getItem('stacked-daily-best-v1')),null);assert.equal(await a.page.evaluate(()=>__qaDailyWorkers.length),0);report.cases.push('Undo assistance cannot create a daily best');await assisted.close();
 const cancelling=await browser.newContext({serviceWorkers:'block'});await observe(cancelling,{holdWorker:true});const cancel=await enter(cancelling);await finishRun(cancel.page,cancel.f,{pending:true});await cancel.page.waitForFunction(()=>__qaDailyWorkers.length===1);await cancel.f.locator('#overlayExitButton').click();await cancel.page.locator('iframe[src*="/stacked/index.html"]').waitFor({state:'detached'});assert.equal(await cancel.page.evaluate(()=>localStorage.getItem('stacked-daily-best-v1')),null);report.cases.push('close while verification is pending prevents daily write');await cancelling.close();
 const proof=await browser.newPage();await proof.goto(origin);const fixture=JSON.parse(fs.readFileSync(path.join(repo,'tests/fixtures/stacked-maximal-priority-rotation-run.json'))),bytes=gunzipSync(fs.readFileSync(path.join(repo,'tests/fixtures/stacked-maximal-priority-rotation-run.sic1.gz')));
 report.replay=await proof.evaluate(async({base64,options})=>{const w=new Worker('/dist/stacked/verify-worker.js',{type:'module'});let timer;try{return await new Promise((resolve,reject)=>{timer=setTimeout(()=>reject(Error('worker timeout')),15000);w.onerror=e=>reject(Error(e.message));w.onmessage=e=>resolve(e.data);w.postMessage({requestId:'daily-unchanged',evidence:Uint8Array.from(atob(base64),c=>c.charCodeAt(0)),...options});});}finally{clearTimeout(timer);w.terminate();}},{base64:bytes.toString('base64'),options:fixture.replayOptions});assert.deepEqual(report.replay,{requestId:'daily-unchanged',ok:true,tuple:fixture.expectedTuple});report.cases.push('actual built Worker preserves 432000-tick tuple');
 assert.equal(report.pageErrors.length,0);report.passed=true;
}catch(e){report.failure=e.stack;process.exitCode=1;if(lastPage&&!lastPage.isClosed())try{await lastPage.screenshot({path:path.join(out,'failure.png')});}catch{}}
finally{if(browser)await bounded('browser connection',()=>browser.close());if(browserServer)report.browserServerClosed=await bounded('browser server',()=>browserServer.close());if(chromeClosePromise)await bounded('Chrome close event',()=>chromeClosePromise);report.chromeProcessCloseObserved=chromeClosed;if(server){server.closeAllConnections();report.serverCloseObserved=await bounded('HTTP server',()=>new Promise(resolve=>server.close(resolve)));}if(report.cleanupErrors.length){report.passed=false;process.exitCode=1;}save();console.log(JSON.stringify({passed:report.passed,cases:report.cases,captures:report.captures.length,chromeClosed,serverClosed:report.serverCloseObserved,failure:report.failure}));}
