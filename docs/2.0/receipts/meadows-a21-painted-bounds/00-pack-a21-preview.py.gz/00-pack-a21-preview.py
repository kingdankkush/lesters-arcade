"""Technical lossless atlas assembly for native A21 layers; no image retouching."""
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
from PIL import Image
from meadows_preview_pack import plan_preview_pages

SOURCE_HASHES = {
    'oak':'63c8da08bfcd68b4d078ffd6be1b4ef3d15f91c0f6aabb3b38790c4bb5f0c17c',
    'shrub':'61cc66284f586d05ca11607ebcd4a4639365da4d000b08c394e79b6101ed93cf',
    'fern':'4fc71c6927acd1b8f4e7b5efa02ae045edc307c5bf790e5d4e864f15449b8041',
}
def sha(data): return hashlib.sha256(data).hexdigest()
def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def bounds(image):
    a = image.getchannel('A').getbbox()
    if a is None: raise ValueError('Blank native layer')
    return dict(zip(('x','y','w','h'), (a[0],a[1],a[2]-a[0],a[3]-a[1])))

def pack(layers_path, expected_sha, output):
    raw = layers_path.read_bytes()
    if sha(raw) != expected_sha: raise ValueError('Native layer manifest changed')
    layers = json.loads(raw)
    plan = plan_preview_pages(layers)
    native_path = layers_path.with_name('native-study.json')
    pixels_path = layers_path.with_name('actual-pixels.json')
    native, pixels = read(native_path), read(pixels_path)
    if not (native['nativeComplete'] is True and native['artAccepted'] is False
            and native['runtimeAdmission'] is False and native['sourceFilesUnchanged'] is True
            and native['sourcesBefore'] == native['sourcesAfter'] and pixels['passed'] is True):
        raise ValueError('Completed, source-preserving private native study required')
    if native['inputsSha256'] != layers['inputsSha256']: raise ValueError('Layer/native input mismatch')
    if native.get('previewLayers', {}).get('sha256') != expected_sha:
        raise ValueError('Native receipt does not bind these layers')
    source_assets = layers['sourceAssets']
    source_files = {}
    for kind, expected in SOURCE_HASHES.items():
        path = Path(source_assets['plants'][kind])
        if sha(path.read_bytes()) != expected: raise ValueError('Original plant identity differs: '+kind)
        source_files[path] = expected
    for row in [source_assets['house'], source_assets['road'], *source_assets['ground'].values()]:
        path = Path(row['path'])
        if path.stat().st_size != row['bytes'] or sha(path.read_bytes()) != row['sha256']:
            raise ValueError('Original source identity differs: '+str(path))
        source_files[path] = row['sha256']
    if source_assets['house']['sha256'] != 'a63251de2278f8de195776a0d9eac2304c1ad70224063f1ec87b57f491356fb8':
        raise ValueError('Owner farmhouse identity differs')
    originals = {}
    images = []
    for row in [layers['ground'], *layers['props']]:
        path = layers_path.with_name(row['file'])
        content = path.read_bytes(); originals[path] = sha(content)
        if len(content) != row['bytes'] or sha(content) != row['sha256']:
            raise ValueError('Native image changed: '+row['file'])
        with Image.open(path) as source: image = source.convert('RGBA')
        if image.size != (row['width'],row['height']) or bounds(image) != row['alphaBounds']:
            raise ValueError('Native image measurement differs')
        images.append(image)
    ground = images[0]
    cards = Image.new('RGBA', plan['propPageSize'])
    for index,image in enumerate(images[1:]): cards.paste(image,(0,index*768))
    pages = [ground.crop(p['crop']) for p in plan['ground']] + [cards]
    if output.exists(): raise ValueError('Preserve earlier packed results')
    output.mkdir()
    page_records = []
    for image,name in zip(pages,('ground-north-preview.webp','ground-south-preview.webp','props-preview.webp')):
        target = output/name
        image.save(target,format='WEBP',lossless=True,method=4,exact=True)
        with Image.open(target) as source: decoded = source.convert('RGBA')
        if decoded.size != image.size or decoded.tobytes() != image.tobytes():
            raise ValueError('Technical atlas encoding changed pixels')
        page_records.append({'image':name,'width':image.width,'height':image.height,
                             'bytes':target.stat().st_size,'sha256':sha(target.read_bytes()),
                             'decodedRgbaSha256':sha(decoded.tobytes())})
    for index,image in enumerate(images[1:]):
        if cards.crop((0,index*768,768,(index+1)*768)).tobytes() != image.tobytes():
            raise ValueError('Prop card pixels differ')
    joined = Image.new('RGBA',ground.size)
    joined.paste(pages[0],(0,0)); joined.paste(pages[1],(0,768))
    if joined.tobytes() != ground.tobytes(): raise ValueError('Ground split changed pixels')
    material = native['paletteStudy']
    if material.get('allChangesObjectLinked') is not True or material.get('originalTextureBytesPreserved') is not True:
        raise ValueError('Private copied-material provenance required')
    tier = {'pages':page_records,'frames':plan['frames'],'decodedBytes':plan['decodedBytes'],
            'encodedBytes':sum(p['bytes'] for p in page_records)}
    metadata = {'schema':'hmh-meadows-art-target/v1','runtimeAuthority':'projection-only','ownerAccepted':False,
                'palette':'muted-environment','calibrationPreview':True,'projectionAdapter':layers['projectionAdapter'],
                'previewDensity':{'texelsPerMetre':64,'final128TexelsPerMetreAccepted':False},
                'sources':{'oak':{'method':'existing-owner-mixed-vegetation-study','sha256':sha(native_path.read_bytes())},
                           'house':{'method':'existing-owner-model','sha256':source_assets['house']['sha256']}},
                'mixedVegetationStudy':{'schema':'hmh-mixed-vegetation-study/v1','nativeComplete':True,
                    'calibrationPreview':True,'artAccepted':False,'runtimeAdmission':False,'visibleBarrierAccepted':False,
                    'sources':{kind:{'sourceSha256':value,
                       'beforeDataSha256':native['sourcesBefore'][kind]['geometryNormalsUvMaterialsImagesSha256'],
                       'afterDataSha256':native['sourcesAfter'][kind]['geometryNormalsUvMaterialsImagesSha256']}
                       for kind,value in SOURCE_HASHES.items()},
                    'materialStudy':deepcopy(material),'nativeReceiptSha256':sha(native_path.read_bytes()),
                    'actualPixelsSha256':sha(pixels_path.read_bytes()),'inputManifestSha256':layers['inputsSha256']},
                'tiers':{'desktop':deepcopy(tier),'mobile':deepcopy(tier)}}
    if any(sha(path.read_bytes()) != value for path,value in {**originals, **source_files}.items()) or sha(layers_path.read_bytes()) != expected_sha:
        raise ValueError('Original native pixels or layer manifest changed')
    (output/'manifest.json').write_text(json.dumps(metadata,indent=2)+'\n',encoding='utf8')
    proof = {'passed':True,'calibrationPreview':True,'artAccepted':False,'runtimeAdmission':False,
             'nativeLayersSha256':expected_sha,'sourcePixelsPreserved':True,'groundReassemblyIdentical':True,
             'propCardsUncropped':True,'densityTexelsPerMetre':64,'tiersShareSamePreviewPages':True,
             'encodedBytes':tier['encodedBytes'],'decodedBytes':tier['decodedBytes']}
    (output/'pack-proof.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
    return proof

if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--layers',type=Path,required=True); parser.add_argument('--layers-sha256',required=True)
    parser.add_argument('--output',type=Path,required=True); args=parser.parse_args()
    print(json.dumps(pack(args.layers,args.layers_sha256,args.output)))
