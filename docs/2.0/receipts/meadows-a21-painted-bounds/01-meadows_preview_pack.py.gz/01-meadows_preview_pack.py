"""Exact, uncropped A21 calibration-page layout; no runtime or art approval."""
from copy import deepcopy
import math
import re


def plan_preview_pages(layers):
    def need(condition, message):
        if not condition:
            raise ValueError(message)

    def finite(value):
        return type(value) in (int, float) and math.isfinite(value)

    def image(row, file, width, height):
        need(isinstance(row, dict), 'Image row required')
        need(row.get('file') == file and row.get('width') == width and row.get('height') == height,
             'Exact named native image and extent required')
        need(type(row.get('bytes')) is int and row['bytes'] > 0, 'Positive image bytes required')
        need(isinstance(row.get('sha256'), str) and re.fullmatch('[0-9a-f]{64}', row['sha256']),
             'Image checksum required')
        a = row.get('alphaBounds', {})
        need(all(type(a.get(key)) is int for key in ('x','y','w','h')), 'Integer alpha bounds required')
        need(a['x'] >= 0 and a['y'] >= 0 and a['w'] > 0 and a['h'] > 0
             and a['x']+a['w'] <= width and a['y']+a['h'] <= height, 'Alpha bounds exceed image')

    need(isinstance(layers, dict) and layers.get('schema') == 'hmh-private-meadows-layers/v1',
         'A21 calibration layer manifest required')
    need(layers.get('calibrationPreview') is True and layers.get('artAccepted') is False
         and layers.get('runtimeAdmission') is False and layers.get('worldUnitsPerMetre') == 40,
         'Unaccepted 40-unit calibration preview required')
    adapter = layers.get('projectionAdapter', {})
    expected = {'cameraPitchFromVerticalDegrees':55, 'zPrewarp':1/math.tan(math.radians(55)),
                'spriteYScale':1/math.cos(math.radians(55))}
    need(adapter.get('handedness') == 'worldY=-BlenderY', 'World handedness differs')
    need(all(finite(adapter.get(key)) and abs(adapter[key]-value) < 1e-12 for key,value in expected.items()),
         'Measured projection adapter differs')
    ground = layers.get('ground')
    image(ground, 'ground-preview.png', 1024, 1536)
    need(ground.get('worldRect') == {'x':120,'y':1000,'width':640,'height':960}, 'Ground coverage differs')
    need(ground.get('texelsPerMetre') == 64 and ground.get('final128TexelsPerMetreAccepted') is False,
         'This is a 64-texel calibration preview')
    props = layers.get('props')
    need(isinstance(props, list) and len(props) == 2, 'Exactly two prop cards required')
    frames = []
    for index,(row,asset,file) in enumerate(zip(props,
        ('art-target-meadows-tree-oak','art-target-meadows-house'),
        ('understory-preview.png','house-preview.png'))):
        image(row, file, 768, 768)
        need(row.get('assetId') == asset, 'Prop order/identity differs')
        anchor,pivot = row.get('anchor',{}),row.get('groundPivotPixels',{})
        need(all(finite(anchor.get(axis)) and 0 <= anchor[axis] <= 1 and finite(pivot.get(axis))
                 and abs(anchor[axis]*768-pivot[axis]) < 1e-8 for axis in ('x','y')),
             'Measured card pivot/anchor differs')
        need(finite(row.get('runtimeScale')) and row['runtimeScale'] > 0
             and finite(row.get('projectionY')) and abs(row['projectionY']-expected['spriteYScale']) < 1e-12,
             'Prop scale/projection invalid')
        frames.append({'assetId':asset, 'page':2, 'frame':{'x':0,'y':index*768,'w':768,'h':768},
                       'anchor':deepcopy(anchor), 'runtimeScale':row['runtimeScale'],
                       'projectionY':row['projectionY'], 'alphaBounds':deepcopy(row['alphaBounds'])})
    return {'ground':[{'crop':(0,0,1024,768),'worldRect':{'x':120,'y':1000,'width':640,'height':480}},
                      {'crop':(0,768,1024,1536),'worldRect':{'x':120,'y':1480,'width':640,'height':480}}],
            'propPageSize':(768,1536), 'frames':frames,
            'decodedBytes':(2*1024*768+768*1536)*4}
