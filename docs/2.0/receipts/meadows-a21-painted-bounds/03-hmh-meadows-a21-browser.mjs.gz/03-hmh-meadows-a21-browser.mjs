// Actual game comparison with three lossless native calibration pages; no production assets replaced.
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { startPortalStaticServer } from 'file:///C:/Users/just_/lesters-arcade-wt/200-art-slice/scripts/hmh-reboot-portal-e2e.mjs';
import { createMeadowsArtTargetPlan } from 'file:///C:/Users/just_/lesters-arcade-wt/200-art-slice/apps/hmh-reboot/src/meadows-art-target.mjs';
import { LEVEL_ONE_WORLD } from 'file:///C:/Users/just_/lesters-arcade-wt/200-art-slice/apps/hmh-reboot/src/level-one-world.mjs';
import { measureMeadowsComposition } from 'file:///C:/Users/just_/lesters-arcade-wt/200-art-slice/scripts/lib/hmh-meadows-composition-metrics.mjs';
import { observeChromeProcess, closeQaBrowserResources } from 'file:///C:/Users/just_/lesters-arcade-wt/200-art-slice/scripts/lib/hmh-owned-browser-close.mjs';
import { chromium } from 'file:///C:/Users/just_/lesters-arcade-wt/200-art-slice/benchmarks/hmh-engine-bakeoff/node_modules/playwright/index.mjs';
const repoRoot='C:/Users/just_/lesters-arcade-wt/200-art-slice';
const outputArg=process.argv.indexOf('--output');
const output=path.resolve(outputArg<0?path.join(repoRoot,'.hermes/evidence/hmh-meadows-art-target'):process.argv[outputArg+1]);
await mkdir(output,{recursive:true});
const arg=name=>{const i=process.argv.indexOf(name);assert.ok(i>=0,'Missing '+name);return process.argv[i+1];};
const overrideRoot=path.resolve(arg('--pack'));
const manifestBytes=await readFile(path.join(overrideRoot,'manifest.json'));
const digest=bytes=>createHash('sha256').update(bytes).digest('hex');
assert.equal(digest(manifestBytes),arg('--manifest-sha256'),'Private manifest changed');
const manifest=JSON.parse(manifestBytes.toString('utf8'));
assert.equal(manifest.calibrationPreview,true);assert.equal(manifest.ownerAccepted,false);
assert.equal(manifest.previewDensity.texelsPerMetre,64);
assert.equal(manifest.previewDensity.final128TexelsPerMetreAccepted,false);
assert.equal(manifest.mixedVegetationStudy.artAccepted,false);
assert.equal(manifest.mixedVegetationStudy.runtimeAdmission,false);
const overrideBodies=new Map([['manifest.json',manifestBytes]]);
for(const tier of ['desktop','mobile'])for(const page of manifest.tiers[tier].pages){
 assert.match(page.image,/^(?:ground-north|ground-south|props)-preview\.webp$/);
 const bytes=await readFile(path.join(overrideRoot,page.image));
 assert.equal(bytes.length,page.bytes);assert.equal(digest(bytes),page.sha256);
 if(overrideBodies.has(page.image))assert.deepEqual(overrideBodies.get(page.image),bytes);
 else overrideBodies.set(page.image,bytes);
}
assert.equal(overrideBodies.size,4);
assert.deepEqual(manifest.tiers.desktop.pages,manifest.tiers.mobile.pages);
let server,origin,browser,browserServer,chromeObserver,browserLaunchAttempted=false,failure=null,closure;
const sceneArg=process.argv.indexOf('--scene');
const selectedScenes=sceneArg<0?null:new Set(process.argv[sceneArg+1].split(','));
const scenes=[];
const state=page=>page.locator('#hmhRebootStage').evaluate(stage=>({...stage.dataset}));
async function moveAxis(page,key,axis,target){
 const start=Number((await state(page))[axis]);const ascending=target>start;
 await page.keyboard.down(key);
 try{await page.waitForFunction(({axis,target,ascending})=>{const value=Number(document.querySelector('#hmhRebootStage')?.dataset[axis]);return ascending?value>=target:value<=target},{axis,target,ascending},{timeout:8000});}
 finally{await page.keyboard.up(key);}
 await page.waitForTimeout(120);
}
async function capture({id,mobile=false,enabled=false,moves=[],hold=null,failure=false}){
 if(selectedScenes&&!selectedScenes.has(id))return;
 const viewport=mobile?{width:414,height:896}:{width:1440,height:900};
 const context=await browser.newContext({viewport,deviceScaleFactor:mobile?3:1,isMobile:mobile,hasTouch:mobile});
 const page=await context.newPage();const errors=[],requests=[],consoleErrors=[],overrides=[];
 await page.route('**/assets/generated/hmh-art-target/**',async route=>{
  try{
  const url=new URL(route.request().url());
  const prefix='/assets/generated/hmh-art-target/';
  const name=url.pathname.startsWith(prefix)?url.pathname.slice(prefix.length):'';
  assert.equal(url.origin,origin,'Only this local server may request overrides');
  assert.equal(overrideBodies.has(name),true,'Unexpected art override request');
  const body=overrideBodies.get(name);overrides.push({name,sha256:digest(body),bytes:body.length});
  await route.fulfill({status:200,contentType:name.endsWith('.json')?'application/json':'image/webp',body});
  }catch(error){errors.push('Private override rejected: '+String(error.message));await route.abort('failed').catch(()=>{});}
 });
 page.on('pageerror',error=>errors.push(String(error.message)));
 page.on('console',message=>{if(message.type()==='error')consoleErrors.push(message.text());});
 page.on('response',response=>{if(response.url().includes('/hmh-art-target/'))requests.push({url:response.url(),status:response.status()});});
 if(failure)await page.route('**/hmh-art-target/ground-south-*.webp',route=>route.abort('failed'));
 const query=new URLSearchParams({evidenceSafe:'1',telemetry:'1',worldTour:'farmhouse'});if(enabled)query.set('artTarget','meadows-v1');
 const url=`${origin}/hmh-reboot/index.html?${query}`;
 try{
  await page.goto(url,{waitUntil:'domcontentloaded'});
  await page.waitForFunction(()=>{const d=document.querySelector('#hmhRebootStage')?.dataset;return d?.startupArt==='ready'&&d.authoredPropStatus==='ready'&&d.actorArtSource==='packed-textured-blend';},null,{timeout:45000});
  if(enabled)await page.waitForFunction(failure=>document.querySelector('#hmhRebootStage')?.dataset.artTargetStatus===(failure?'fallback':'review-candidate'),failure,{timeout:15000});
  await page.locator('#hmhRebootStage canvas').focus();await page.mouse.move(viewport.width*.9,viewport.height*.65);
  for(const move of moves)await moveAxis(page,move.key,move.axis,move.target);
  let crossing=null;
  if(hold){
   await page.keyboard.down(hold.key);
   try{await page.waitForFunction(id=>document.querySelector('#hmhRebootStage')?.dataset.collisionBlocker===id,hold.blockerId,{timeout:4000});crossing=await state(page);}
   finally{await page.keyboard.up(hold.key);}
   assert.ok(Number(crossing.actorY)>=1269-.1,'actor crossed the legal hedgerow edge');
  }
  // Pause only through the shipped control handler; no simulated state is edited.
  await page.keyboard.press('Escape');await page.waitForTimeout(250);
  await page.evaluate(()=>{for(const node of document.querySelectorAll('.hmh-modal-layer'))node.style.display='none';});
  const observed=await state(page);await page.waitForTimeout(180);const settled=await state(page);
  assert.equal(settled.simulationTick,observed.simulationTick,'pause did not freeze the real game');
  if(!enabled){assert.equal(requests.length,0,'default-off game requested pilot art');assert.equal(overrides.length,0,'default-off requested override');}
  if(enabled&&!failure)assert.deepEqual([...new Set(overrides.map(value=>value.name))].sort(),['manifest.json',...manifest.tiers[mobile?'mobile':'desktop'].pages.map(page=>page.image)].sort(),'Actual game did not load all expected private pages');
  if(enabled&&!failure){assert.equal(Number(observed.artTargetDecodedBytes),manifest.tiers[mobile?'mobile':'desktop'].decodedBytes);assert.equal(Number(observed.artTargetEncodedBytes),manifest.tiers[mobile?'mobile':'desktop'].encodedBytes);}
  if(enabled&&failure)assert.equal(observed.artTargetCleanupFailures,'0','failed-load cleanup telemetry must confirm no retained pages');
  assert.deepEqual(errors,[]);
  const screenshot=path.join(output,id+'.png');await page.screenshot({path:screenshot,fullPage:true});
  const hud=await page.locator('[data-hmh-control]').evaluateAll(nodes=>nodes.map(node=>{const r=node.getBoundingClientRect();return {control:node.dataset.hmhControl,x:r.x,y:r.y,width:r.width,height:r.height};}));
  const hudRects=await page.locator('#hmhHud,.hmh-reboot-status-card').evaluateAll(nodes=>nodes.map(node=>{const r=node.getBoundingClientRect();return {id:node.id||node.className,x:r.x,y:r.y,width:r.width,height:r.height};}).filter(r=>r.width&&r.height));
  const canvasHud=observed.artTargetCanvasHud?JSON.parse(observed.artTargetCanvasHud):{rectangles:[],errors:[]};
  assert.deepEqual(canvasHud.errors,[],'actual canvas HUD bounds unavailable');
  const composition=enabled&&!failure?measureMeadowsComposition({observed,bindings:createMeadowsArtTargetPlan(LEVEL_ONE_WORLD).bindings,frames:manifest.tiers[mobile?'mobile':'desktop'].frames,viewport,hudRects,canvasHudRects:canvasHud.rectangles,controlRects:hud.filter(r=>r.width&&r.height)}):null;
  const result={id,url,screenshot,viewport,deviceScaleFactor:mobile?3:1,deviceEvidence:mobile?'XS Max framing proxy on Windows Chrome; physical phone untested':'Windows desktop Chrome',qaOnly:true,privateA21LayerOverride:true,calibrationPreview:true,overrides,gameplayStateEdited:false,crossing,observed,requests,errors,consoleErrors,hud,hudRects,canvasHud,composition,legacyStaticQuietBandLabel:mobile?{top:266,bottom:viewport.height-240}:{top:185,bottom:viewport.height-95}};
  await writeFile(path.join(output,id+'.runtime.json'),JSON.stringify(result,null,2)+'\n');scenes.push(result);
  console.log('ART_A2_CAPTURE '+screenshot);
 }catch(error){const failed={id,url,error:String(error.stack??error),state:await state(page).catch(()=>null),errors,requests};await writeFile(path.join(output,id+'.failure.json'),JSON.stringify(failed,null,2)+'\n');await page.screenshot({path:path.join(output,id+'.failure.png'),fullPage:true}).catch(()=>{});throw error;}
 finally{await context.close();}
}
try{
 ({server,origin}=await startPortalStaticServer({rootDir:path.join(repoRoot,'apps/portal')}));
 browserLaunchAttempted=true;
 browserServer=await chromium.launchServer({executablePath:process.env.HMH_REBOOT_BROWSER_EXECUTABLE??String.raw`C:\Program Files\Google\Chrome\Application\chrome.exe`,headless:true,args:['--enable-gpu','--ignore-gpu-blocklist','--enable-webgl','--hide-scrollbars']});
 chromeObserver=observeChromeProcess(browserServer);
 browser=await chromium.connect(browserServer.wsEndpoint());
 await capture({id:'meadows-before-desktop'});
 await capture({id:'meadows-candidate-desktop',enabled:true});
 await capture({id:'meadows-candidate-phone-house',enabled:true,mobile:true,moves:[{key:'a',axis:'actorX',target:480}]});
 await capture({id:'meadows-before-phone-house',mobile:true,moves:[{key:'a',axis:'actorX',target:480}]});
 await capture({id:'meadows-candidate-desktop-lane',enabled:true,moves:[{key:'w',axis:'actorY',target:1510}]});
 await capture({id:'meadows-candidate-phone-oak',enabled:true,mobile:true,moves:[{key:'w',axis:'actorY',target:1530},{key:'a',axis:'actorX',target:400},{key:'w',axis:'actorY',target:1340}]});
 await capture({id:'meadows-candidate-phone-oak-crossing',enabled:true,mobile:true,moves:[{key:'w',axis:'actorY',target:1530},{key:'a',axis:'actorX',target:400},{key:'w',axis:'actorY',target:1340}],hold:{key:'w',blockerId:'relay-hedgerow'}});
 await capture({id:'meadows-candidate-desktop-north',enabled:true,moves:[{key:'w',axis:'actorY',target:1530},{key:'a',axis:'actorX',target:400},{key:'w',axis:'actorY',target:1340},{key:'d',axis:'actorX',target:560},{key:'w',axis:'actorY',target:1090},{key:'a',axis:'actorX',target:330}]});
 await capture({id:'meadows-candidate-phone-corner',enabled:true,mobile:true,moves:[{key:'w',axis:'actorY',target:1530},{key:'a',axis:'actorX',target:400},{key:'w',axis:'actorY',target:1490}]});
 await capture({id:'meadows-before-phone-corner',mobile:true,moves:[{key:'w',axis:'actorY',target:1530},{key:'a',axis:'actorX',target:400},{key:'w',axis:'actorY',target:1490}]});
 await capture({id:'meadows-candidate-phone-corner-north',enabled:true,mobile:true,moves:[{key:'w',axis:'actorY',target:1530},{key:'a',axis:'actorX',target:400},{key:'w',axis:'actorY',target:1450}]});
 await capture({id:'meadows-before-desktop-corner',moves:[{key:'w',axis:'actorY',target:1530},{key:'a',axis:'actorX',target:400},{key:'w',axis:'actorY',target:1490}]});
 await capture({id:'meadows-candidate-desktop-corner',enabled:true,moves:[{key:'w',axis:'actorY',target:1530},{key:'a',axis:'actorX',target:400},{key:'w',axis:'actorY',target:1490}]});
 await capture({id:'meadows-candidate-fail-safe',enabled:true,failure:true});
}catch(error){failure=error;}
finally{
 closure=await closeQaBrowserResources({browser,browserServer,chromeObserver,server,browserLaunchAttempted});
 await writeFile(path.join(output,'ART-A21-browser-closure.json'),JSON.stringify(closure,null,2)+'\n');
 await writeFile(path.join(output,'ART-A21-browser.json'),JSON.stringify({schema:'hmh-meadows-art-target-browser/v1',ownerAccepted:false,physicalPhoneTested:false,passed:!failure&&closure.allResourcesClosed&&closure.cleanupErrors.length===0,failure:failure?String(failure.stack):null,closure,scenes},null,2)+'\n');
}
console.log(JSON.stringify({passed:!failure&&closure.allResourcesClosed&&closure.cleanupErrors.length===0,closure,scenes:scenes.map(scene=>({id:scene.id,screenshot:scene.screenshot,actorX:scene.observed.actorX,actorY:scene.observed.actorY,zoom:scene.observed.cameraZoom,artTargetStatus:scene.observed.artTargetStatus,nativeAssetIds:scene.observed.nativePropOnscreenAssetIds}))},null,2));
if(failure)throw failure;
if(!closure.allResourcesClosed||closure.cleanupErrors.length)throw new Error('QA Chrome/HTTP cleanup failed; inspect retained closure witness');
