// One bounded pack/build/actual-game/default-visual window, using existing cleanup.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash,randomUUID} from 'node:crypto';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {runOwnedWindowsChild} from './owned-windows-world-visual-child.mjs';
const work=fileURLToPath(new URL('.',import.meta.url));
const repo='C:/Users/just_/lesters-arcade-wt/200-art-slice';
const [layersPath,layersSha,outputArg]=process.argv.slice(2);
const output=path.resolve(outputArg),pack=path.join(output,'packed'),screens=path.join(output,'screens');
const hash=p=>createHash('sha256').update(fs.readFileSync(p)).digest('hex');
assert.match(layersSha??'',/^[0-9a-f]{64}$/);assert.equal(hash(layersPath),layersSha);
const marker='C:/Users/just_/lesters-arcade-wt/.locks/heavy.lock';
assert.ok(!fs.existsSync(marker)&&!fs.existsSync(output));
const portal=path.join(repo,'apps/portal'),dist=path.join(portal,'dist');
assert.equal(fs.realpathSync(portal).toLowerCase(),path.resolve(portal).toLowerCase());
if(fs.existsSync(dist)){
 assert.equal(fs.lstatSync(dist).isSymbolicLink(),false,'Build output may not be a junction');
 assert.equal(fs.realpathSync(dist).toLowerCase(),path.resolve(dist).toLowerCase());
}
const playwright=path.join(repo,'benchmarks/hmh-engine-bakeoff/node_modules/playwright/index.mjs');
const inputFiles=[layersPath,...['pack-a21-preview.py','meadows_preview_pack.py','hmh-meadows-a21-browser.mjs','run-a21-game-preview.mjs','owned-windows-world-visual-child.mjs'].map(f=>path.join(work,f)),...['apps/hmh-reboot/src/meadows-art-target.mjs','apps/hmh-reboot/src/main.mjs','apps/hmh-reboot/src/level-one-world.mjs','scripts/hmh-reboot-portal-e2e.mjs','scripts/lib/hmh-meadows-composition-metrics.mjs','scripts/lib/hmh-owned-browser-close.mjs','build.mjs'].map(f=>path.join(repo,f)),playwright,fs.realpathSync(playwright)];
const before=Object.fromEntries(inputFiles.map(f=>[f,hash(f)]));
fs.mkdirSync(output);fs.mkdirSync(screens);fs.mkdirSync(marker);
const token=randomUUID();fs.writeFileSync(path.join(marker,'owner.json'),JSON.stringify({owner:'/root',token,task:'A21 native layers in actual game'}));
const report={passed:false,artAccepted:false,physicalPhoneTested:false,before,commands:[]};let closed=true;
const save=()=>fs.writeFileSync(path.join(output,'receipt.json'),JSON.stringify(report,null,2)+'\n');
function absent(pid){try{process.kill(pid,0);throw new Error('Owned process still present: '+pid);}catch(e){assert.equal(e.code,'ESRCH');}}
async function run(name,program,args,seconds,closurePath){
 closed=false;save();
 const r=await runOwnedWindowsChild(program,args,{cwd:repo,env:{...process.env,PYTHONDONTWRITEBYTECODE:'1'},watchdogMs:seconds*1000,maxOutputBytes:4*1024*1024});
 report.commands.push({name,...r});fs.writeFileSync(path.join(output,name+'.log'),r.stdout+r.stderr);
 assert.equal(r.childClosureConfirmed,true);absent(r.spawnedPid);
 if(closurePath){const c=JSON.parse(fs.readFileSync(closurePath));report.commands.at(-1).browserClosure=c;
  assert.ok(c.allResourcesClosed===true&&c.chromeProcessCloseObserved===true&&c.serverCloseObserved===true&&c.cleanupErrors.length===0);
  assert.equal(c.chromeClose.code,0);assert.equal(c.chromeClose.signal,null);absent(c.spawnedChromePid);}
 closed=true;
 save();assert.ok(closed);assert.equal(r.exitCode,0);assert.equal(r.signal,null);assert.equal(r.watchdogTriggered,false);assert.equal(r.outputLimitTriggered,false);
 assert.deepEqual(Object.fromEntries(inputFiles.map(f=>[f,hash(f)])),before);
 console.log(JSON.stringify({name,passed:true,pid:r.spawnedPid,seconds:r.wholeChildWallMs/1000}));return r;
}
try{
 await run('pack','C:/Users/just_/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe',['-B','-X','utf8',path.join(work,'pack-a21-preview.py'),'--layers',layersPath,'--layers-sha256',layersSha,'--output',pack],30);
 const metadata=JSON.parse(fs.readFileSync(path.join(pack,'manifest.json')));
 const {validateMeadowsArtMetadata}=await import(pathToFileURL(path.join(repo,'apps/hmh-reboot/src/meadows-art-target.mjs')));
 for(const tier of ['desktop','mobile'])assert.equal(validateMeadowsArtMetadata(metadata,tier).decodedBytes,11010048);
 const build=await run('build',process.execPath,['build.mjs','--metafile'],40);
 const match=/HMH initial JS \+ shared:[^\n]*\(([\d,]+) B\)/.exec(build.stdout);assert.ok(match);
 report.initialJsBytes=Number(match[1].replaceAll(',',''));assert.ok(report.initialJsBytes<=1048576);
 await run('game',process.execPath,[path.join(work,'hmh-meadows-a21-browser.mjs'),'--pack',pack,'--manifest-sha256',hash(path.join(pack,'manifest.json')),'--scene','meadows-before-desktop,meadows-candidate-desktop,meadows-candidate-phone-house,meadows-candidate-phone-oak-crossing,meadows-candidate-desktop-north,meadows-candidate-fail-safe','--output',screens],120,path.join(screens,'ART-A21-browser-closure.json'));
 const browser=JSON.parse(fs.readFileSync(path.join(screens,'ART-A21-browser.json')));
 assert.equal(browser.passed,true);assert.equal(browser.scenes.length,6);
 assert.ok(browser.scenes.every(s=>s.errors.length===0&&(s.id.endsWith('fail-safe')||s.consoleErrors.length===0)));
 const visual=await run('default-visual',process.execPath,['C:/Program Files/nodejs/node_modules/npm/bin/npm-cli.js','run','visual:reboot','--','--closure-receipt',path.join(output,'default-visual-closure.json')],180,path.join(output,'default-visual-closure.json'));
 const start=visual.stdout.indexOf('{\n  "schema"'),end=visual.stdout.lastIndexOf('}\n');assert.ok(start>=0&&end>start);
 const metrics=JSON.parse(visual.stdout.slice(start,end+1));assert.equal(metrics.accepted,false);assert.equal(metrics.results.length,12);
 assert.ok(metrics.results.every(r=>r.status==='unchanged'&&r.errors.length===0));
 fs.writeFileSync(path.join(output,'default-visual-metrics.json'),JSON.stringify(metrics,null,2)+'\n');report.passed=true;
}catch(e){report.failure=e.stack;process.exitCode=1;}
finally{
 report.closed=closed;report.after=Object.fromEntries(inputFiles.map(f=>[f,hash(f)]));
 if(closed){assert.equal(JSON.parse(fs.readFileSync(path.join(marker,'owner.json'))).token,token);fs.unlinkSync(path.join(marker,'owner.json'));fs.rmdirSync(marker);report.markerReleased=!fs.existsSync(marker);}
 save();console.log(JSON.stringify({passed:report.passed,closed,markerReleased:report.markerReleased,failure:report.failure}));
}
