import test from 'node:test';
import assert from 'node:assert/strict';
import {MEADOWS_PROJECTION_ADAPTER,validateMeadowsArtMetadata} from './meadows-art-target.mjs';
const hash='a'.repeat(64);
function fixture(){
 const sources={oak:'63c8da08bfcd68b4d078ffd6be1b4ef3d15f91c0f6aabb3b38790c4bb5f0c17c',shrub:'61cc66284f586d05ca11607ebcd4a4639365da4d000b08c394e79b6101ed93cf',fern:'4fc71c6927acd1b8f4e7b5efa02ae045edc307c5bf790e5d4e864f15449b8041'};
 const pages=['ground-north','ground-south','props'].map(image=>({image:image+'.webp',width:768,height:1536,bytes:100,sha256:hash}));
 const frames=['art-target-meadows-tree-oak','art-target-meadows-house'].map((assetId,index)=>({assetId,page:2,frame:{x:0,y:index*768,w:768,h:768},anchor:{x:.5,y:.8},runtimeScale:.5,projectionY:MEADOWS_PROJECTION_ADAPTER.spriteYScale}));
 return {schema:'hmh-meadows-art-target/v1',runtimeAuthority:'projection-only',ownerAccepted:false,palette:'muted-environment',projectionAdapter:MEADOWS_PROJECTION_ADAPTER,
  sources:{oak:{method:'existing-owner-mixed-vegetation-study',sha256:hash},house:{method:'existing-owner-model',sha256:hash}},
  mixedVegetationStudy:{schema:'hmh-mixed-vegetation-study/v1',nativeComplete:true,artAccepted:false,runtimeAdmission:false,visibleBarrierAccepted:false,
   sources:Object.fromEntries(Object.entries(sources).map(([kind,sourceSha256])=>[kind,{sourceSha256,beforeDataSha256:hash,afterDataSha256:hash}])),
   materialStudy:{oakMaterialCopyOnly:true,originalTextureBytesPreserved:true,shaderFidelityToOriginal:false},nativeReceiptSha256:hash,actualPixelsSha256:hash,inputManifestSha256:hash},
  tiers:{desktop:{pages,frames},mobile:{pages,frames}}};
}
function calibration(){const m=fixture();m.calibrationPreview=true;m.mixedVegetationStudy.calibrationPreview=true;m.mixedVegetationStudy.materialStudy.oakMaterialCopyOnly=false;m.mixedVegetationStudy.materialStudy.allChangesObjectLinked=true;return m;}
test('existing oak-only copied-material provenance still loads',()=>{assert.equal(validateMeadowsArtMetadata(fixture(),'desktop').frames.length,2);});
test('explicit calibration permits copied lower-plant materials without falsely claiming oak-only changes',()=>{const m=calibration();assert.equal(validateMeadowsArtMetadata(m,'desktop').frames.length,2);assert.equal(m.mixedVegetationStudy.materialStudy.oakMaterialCopyOnly,false);});
test('unlabelled or unproven mixed-material changes are refused',()=>{for(const change of [m=>delete m.calibrationPreview,m=>delete m.mixedVegetationStudy.calibrationPreview,m=>m.mixedVegetationStudy.materialStudy.allChangesObjectLinked=false]){const m=calibration();change(m);assert.throws(()=>validateMeadowsArtMetadata(m,'desktop'),/provenance/);}});
test('calibration retains original source identity and unaccepted presentation-only boundaries',()=>{for(const change of [m=>m.ownerAccepted=true,m=>m.runtimeAuthority='gameplay',m=>m.mixedVegetationStudy.runtimeAdmission=true,m=>m.mixedVegetationStudy.sources.fern.afterDataSha256='b'.repeat(64),m=>m.mixedVegetationStudy.materialStudy.originalTextureBytesPreserved=false]){const m=calibration();change(m);assert.throws(()=>validateMeadowsArtMetadata(m,'desktop'));}});
