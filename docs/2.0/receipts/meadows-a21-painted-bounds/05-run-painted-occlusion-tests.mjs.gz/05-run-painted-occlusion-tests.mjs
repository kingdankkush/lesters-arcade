import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';
import {randomUUID,createHash} from 'node:crypto';import {fileURLToPath} from 'node:url';
import {runOwnedWindowsChild} from './owned-windows-child.mjs';
const work=fileURLToPath(new URL('.',import.meta.url)),repo='C:/Users/just_/lesters-arcade-wt/visual-overhaul-200';
const phase=process.argv[2];assert.ok(['red','green'].includes(phase));
const out=path.join(work,'painted-occlusion-'+phase+'-01'),marker='C:/Users/just_/lesters-arcade-wt/.locks/heavy.lock';
assert.ok(!fs.existsSync(out)&&!fs.existsSync(marker));
const test='tests/hmh-prop-painted-occlusion.test.mjs',files=new Map();
const sha=b=>createHash('sha256').update(b).digest('hex');
function visit(relative){
 if(files.has(relative))return;
 const bytes=fs.readFileSync(path.join(repo,relative));files.set(relative,{bytes,sha256:sha(bytes)});
 for(const match of bytes.toString().matchAll(/(?:from\s*|import\s*\()\s*['"](\.[^'"]+)['"]/g)){
  const next=path.normalize(path.join(path.dirname(relative),match[1]));assert.ok(!next.startsWith('..'));
  if(next.endsWith('.mjs')||next.endsWith('.js'))visit(next);
 }
}
visit(test);fs.mkdirSync(out);fs.mkdirSync(marker);const token=randomUUID();
fs.writeFileSync(path.join(marker,'owner.json'),JSON.stringify({owner:'/root',token,task:'painted prop bounds '+phase}));
const report={phase,passed:false,files:Object.fromEntries([...files].map(([f,v])=>[f,v.sha256])),commands:[]};let closed=true;
async function run(cwd,args){
 closed=false;const r=await runOwnedWindowsChild(process.execPath,['--test','--test-reporter=tap',...args],{cwd,watchdogMs:20000});report.commands.push(r);
 assert.ok(r.childClosureConfirmed);try{process.kill(r.spawnedPid,0);throw new Error('Child still present');}catch(e){assert.equal(e.code,'ESRCH');}closed=true;
 assert.equal(r.signal,null);assert.equal(r.exitCode,phase==='red'?1:0);assert.match(r.stdout,phase==='red'?/# fail 1\b/:/# fail 0\b/);return r;
}
try{
 await run(repo,phase==='red'?[test]:[test,'tests/hmh-reboot-authored-prop-atlas.test.mjs']);
 if(phase==='green'){
  const copy=path.join(out,'isolated');fs.mkdirSync(copy);
  for(const [relative,value]of files){const target=path.join(copy,relative);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,value.bytes);}
  await run(copy,[test]);
 }
 for(const [relative,value]of files)assert.equal(sha(fs.readFileSync(path.join(repo,relative))),value.sha256);
 report.passed=true;
}catch(e){report.failure=e.stack;process.exitCode=1;}
finally{
 report.closed=closed;
 if(closed){assert.equal(JSON.parse(fs.readFileSync(path.join(marker,'owner.json'))).token,token);fs.unlinkSync(path.join(marker,'owner.json'));fs.rmdirSync(marker);report.markerReleased=!fs.existsSync(marker);}
 fs.writeFileSync(path.join(out,'receipt.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({phase,passed:report.passed,closed,markerReleased:report.markerReleased,pids:report.commands.map(r=>r.spawnedPid),failure:report.failure}));
}
