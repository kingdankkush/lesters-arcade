"""A21 technical atlas layout: source pixels and measured pivots stay intact."""
import copy
import importlib.util
import math
from pathlib import Path
import unittest


def load():
    spec = importlib.util.spec_from_file_location('preview_pack', Path(__file__).with_name('meadows_preview_pack.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def fixture():
    adapter = {'cameraPitchFromVerticalDegrees': 55, 'zPrewarp': 1/math.tan(math.radians(55)),
               'spriteYScale': 1/math.cos(math.radians(55)), 'handedness': 'worldY=-BlenderY'}
    def row(file, w, h):
        return {'file': file, 'width': w, 'height': h, 'bytes': 100,
                'sha256': 'a'*64, 'alphaBounds': {'x': 8, 'y': 10, 'w': w-16, 'h': h-20}}
    props = []
    for asset, file, pivot, scale in [('art-target-meadows-tree-oak', 'understory-preview.png', (320, 540), .5),
                                      ('art-target-meadows-house', 'house-preview.png', (400, 600), .625)]:
        props.append({**row(file, 768, 768), 'assetId': asset, 'groundPivotPixels': dict(zip(('x','y'), pivot)),
                      'anchor': dict(zip(('x','y'), (v/768 for v in pivot))),
                      'runtimeScale': scale, 'projectionY': adapter['spriteYScale']})
    return {'schema': 'hmh-private-meadows-layers/v1', 'calibrationPreview': True,
            'artAccepted': False, 'runtimeAdmission': False, 'worldUnitsPerMetre': 40,
            'projectionAdapter': adapter, 'props': props,
            'ground': {**row('ground-preview.png', 1024, 1536), 'texelsPerMetre': 64,
                       'worldRect': {'x':120,'y':1000,'width':640,'height':960},
                       'final128TexelsPerMetreAccepted': False}}


class PreviewLayout(unittest.TestCase):
    def test_ground_halves_cover_exact_physical_rectangle_without_y_stretch(self):
        result = load().plan_preview_pages(fixture())
        self.assertEqual([p['crop'] for p in result['ground']], [(0,0,1024,768),(0,768,1024,1536)])
        self.assertEqual([p['worldRect'] for p in result['ground']],
                         [{'x':120,'y':1000,'width':640,'height':480}, {'x':120,'y':1480,'width':640,'height':480}])
        self.assertEqual(result['propPageSize'], (768,1536))
        self.assertEqual(result['decodedBytes'], 11010048)

    def test_uncropped_prop_pivots_and_scale_survive_atlas_offset(self):
        source = fixture(); original = copy.deepcopy(source)
        result = load().plan_preview_pages(source)
        for index, frame in enumerate(result['frames']):
            self.assertEqual(frame['assetId'], source['props'][index]['assetId'])
            self.assertEqual(frame['page'], 2)
            self.assertEqual(frame['frame'], {'x':0,'y':index*768,'w':768,'h':768})
            self.assertEqual(frame['anchor'], source['props'][index]['anchor'])
            self.assertEqual(frame['runtimeScale'], source['props'][index]['runtimeScale'])
            self.assertEqual(frame['projectionY'], source['props'][index]['projectionY'])
            # World displacement is relative to card, never whole-atlas origin.
            for offset in ((0,0),(64,0),(0,64)):
                old = tuple((source['props'][index]['groundPivotPixels'][axis]+offset[n]-frame['anchor'][axis]*768)
                            *frame['runtimeScale']*(frame['projectionY'] if n else 1) for n,axis in enumerate(('x','y')))
                self.assertAlmostEqual(old[0], offset[0]*frame['runtimeScale'])
                self.assertAlmostEqual(old[1], offset[1]*frame['runtimeScale']*frame['projectionY'])
        self.assertEqual(source, original)
        result['frames'][0]['anchor']['x'] = 0
        self.assertEqual(source, original)

    def test_wrong_layer_identity_pixels_bounds_and_projection_rejected(self):
        bad = []
        for field, value in [('file','../house.png'),('width',767),('bytes',0),('sha256','bad')]:
            item = fixture(); item['props'][0][field] = value; bad.append(item)
        for key, value in [('x',-1),('w',769),('h',0)]:
            item=fixture(); item['props'][0]['alphaBounds'][key]=value; bad.append(item)
        item=fixture(); item['props'].reverse(); bad.append(item)
        item=fixture(); item['props'][1]['groundPivotPixels']['x']+=1; bad.append(item)
        item=fixture(); item['props'][0]['runtimeScale']=float('nan'); bad.append(item)
        item=fixture(); item['props'][0]['projectionY']=1; bad.append(item)
        item=fixture(); item['projectionAdapter']['zPrewarp']=1; bad.append(item)
        item=fixture(); item['ground']['worldRect']['height']=959; bad.append(item)
        item=fixture(); item['ground']['height']=1535; bad.append(item)
        for candidate in bad:
            with self.assertRaises(ValueError): load().plan_preview_pages(candidate)

    def test_preview_cannot_masquerade_as_accepted_final_density_or_runtime(self):
        for field,value in [('calibrationPreview',False),('artAccepted',True),('runtimeAdmission',True),('worldUnitsPerMetre',39)]:
            item=fixture(); item[field]=value
            with self.assertRaises(ValueError): load().plan_preview_pages(item)
        for field,value in [('texelsPerMetre',128),('final128TexelsPerMetreAccepted',True)]:
            item=fixture(); item['ground'][field]=value
            with self.assertRaises(ValueError): load().plan_preview_pages(item)


if __name__ == '__main__': unittest.main()
