import fs from 'node:fs';import path from 'node:path';import http from 'node:http';import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';import {fileURLToPath,pathToFileURL} from 'node:url';
const work=fileURLToPath(new URL('.',import.meta.url)),repo='C:/Users/just_/lesters-arcade-wt/visual-overhaul-200',root=path.join(repo,'apps/portal');
const token=process.argv[2],out=path.join(work,'blog-pages-browser-01');
assert.equal(JSON.parse(fs.readFileSync('C:/Users/just_/lesters-arcade-wt/.locks/heavy.lock/owner.json')).token,token);
assert.equal(fs.existsSync(out),false);fs.mkdirSync(out);
const {buildBlogIndex}=await import(pathToFileURL(path.join(repo,'scripts/lib/blog-content.mjs')));
const {buildBlogPages}=await import(pathToFileURL(path.join(repo,'scripts/lib/blog-pages.mjs')));
const sources=[['three-games-one-arcade','Three games. One arcade.','guides','2026-09-30'],['reading-the-battlefield','Reading the battlefield','news','2026-09-29'],['one-more-run','One more run','news','2026-09-28']].map(([slug,title,category,date])=>'---\n'+JSON.stringify({slug,title,summary:'An article layout fixture for the combined arcade update. This copy is not published.',category,games:['lester-blaster'],date,status:'published',author:'Lester’s Arcade'})+'\n---\n## Find your next game\n\nThis is a local layout fixture, not a release announcement.\n\n## Read more\n\nUse the links below to browse the journal.');
sources.push('---\n'+JSON.stringify({slug:'hidden-fixture',title:'Hidden draft fixture',summary:'Must never be published.',category:'news',games:[],date:'2026-09-30',status:'draft',author:'Arcade'})+'\n---\nHidden.');
const pages=buildBlogPages(buildBlogIndex(sources,{asOf:'2026-09-30'})),generated=new Map();
for(const page of pages){const url='/'+page.path.replace(/\/index\.html$/,'');generated.set(url,page);const file=path.join(out,'generated',page.path);fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,page.content);}
const {chromium}=await import(pathToFileURL(path.join(repo,'benchmarks/hmh-engine-bakeoff/node_modules/playwright/index.mjs')));
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const assets=new Map(['/src/design-tokens.css','/how-ranked-works.css','/blog/article.css','/assets/brand/lesters-arcade-logo-horizontal.png','/assets/favicon.svg'].map(url=>[url,path.join(root,url)]));
const report={passed:false,scope:'Actual pure blog bundle served locally with three explicitly labelled publication fixtures and one hidden draft. No public build/route activation. Windows mobile viewport, not a physical phone.',cases:[],captures:[],served:{},pageErrors:[],cleanupErrors:[]};
let server,browserServer,browser,chromeClose,chromeClosed=false,page;
async function bounded(name,fn){let timer;try{await Promise.race([fn(),new Promise((_,reject)=>timer=setTimeout(()=>reject(Error(name+' timeout')),5000))]);return true;}catch(error){report.cleanupErrors.push({name,error:error.message});return false;}finally{clearTimeout(timer);}}
async function capture(name){
 const metrics=await page.evaluate(()=>({width:innerWidth,height:innerHeight,scrollWidth:document.documentElement.scrollWidth,url:location.pathname,
  scripts:document.scripts.length,h1:document.querySelectorAll('h1').length,logoReady:document.querySelector('.guide-brand img').naturalWidth>0,
  links:[...document.querySelectorAll('.blog-categories a,.blog-grid h2 a,.blog-related a,.guide-topbar a')].map(a=>({text:a.textContent,box:a.getBoundingClientRect().toJSON()})),
  cards:[...document.querySelectorAll('.blog-grid li')].map(a=>a.getBoundingClientRect().toJSON()),textSize:getComputedStyle(document.querySelector('.blog-grid article > p:not(.blog-card-meta):not(.blog-card-author),.blog-prose p,.blog-empty p')).fontSize,
  current:[...document.querySelectorAll('[aria-current=page]')].map(a=>a.getAttribute('href')),canonical:document.querySelector('link[rel=canonical]').href}));
 assert.ok(metrics.scrollWidth<=metrics.width);assert.equal(metrics.scripts,0);assert.equal(metrics.h1,1);assert.ok(metrics.logoReady);assert.ok(parseFloat(metrics.textSize)>=16);
 assert.ok(metrics.links.every(link=>link.box.height>=44&&link.box.width>0));assert.equal(metrics.canonical,'https://lestersarcade.io'+metrics.url);
 const file=path.join(out,name+'.png');await page.screenshot({path:file});report.captures.push({name,file,sha256:sha(fs.readFileSync(file)),metrics});
}
try{
 server=http.createServer((req,res)=>{try{const url=new URL(req.url,'http://127.0.0.1').pathname,item=generated.get(url),file=assets.get(url),bytes=item?Buffer.from(item.content):file?fs.readFileSync(file):null;
  if(!bytes){res.writeHead(404);res.end();return;}report.served[url]=sha(bytes);res.setHeader('Cache-Control','no-store');res.setHeader('Content-Type',item?.mediaType??(url.endsWith('.css')?'text/css':url.endsWith('.png')?'image/png':'image/svg+xml'));res.end(bytes);
 }catch{res.writeHead(500);res.end();}});
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});report.origin='http://127.0.0.1:'+server.address().port;
 browserServer=await chromium.launchServer({executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true});report.chromePid=browserServer.process().pid;
 chromeClose=new Promise(resolve=>browserServer.process().once('close',(code,signal)=>{report.chromeClose={code,signal};chromeClosed=true;resolve();}));
 browser=await chromium.connect(browserServer.wsEndpoint());report.version=browser.version();
 for(const profile of [{name:'desktop',viewport:{width:1440,height:1000},deviceScaleFactor:1},{name:'phone',viewport:{width:414,height:896},deviceScaleFactor:3,isMobile:true,hasTouch:true},{name:'narrow',viewport:{width:320,height:568},deviceScaleFactor:1}]){
  const {name,...options}=profile,context=await browser.newContext({...options,serviceWorkers:'block',javaScriptEnabled:false,reducedMotion:'reduce'});
  await context.route('**/*',route=>route.request().url().startsWith(report.origin+'/')?route.continue():route.abort());page=await context.newPage();page.on('pageerror',error=>report.pageErrors.push(error.message));page.setDefaultTimeout(7000);
  assert.equal((await page.goto(report.origin+'/blog')).status(),200);assert.equal(await page.locator('.blog-grid article').count(),3);assert.equal(await page.locator('[aria-current=page]').getAttribute('href'),'/blog');await capture(name+'-index');
  if(name==='desktop'){await page.keyboard.press('Tab');assert.ok(await page.locator('.skip-link').evaluate(a=>a===document.activeElement));await page.keyboard.press('Enter');assert.equal(await page.evaluate(()=>document.activeElement.id),'main');report.cases.push('native keyboard skip-link focus');}
  await page.locator('.blog-categories a[href="/blog/category/news"]').click();assert.equal(await page.locator('.blog-grid article').count(),2);assert.equal(await page.locator('[aria-current=page]').getAttribute('href'),'/blog/category/news');await capture(name+'-news');
  await page.locator('.blog-grid h2 a').first().click();assert.equal(new URL(page.url()).pathname,'/blog/reading-the-battlefield');assert.equal(await page.locator('.blog-related a').count(),2);await page.locator('.blog-related').scrollIntoViewIfNeeded();await capture(name+'-related');
  await page.locator('.blog-related a[href="/blog/three-games-one-arcade"]').click();assert.equal(await page.locator('h1').textContent(),'Three games. One arcade.');await page.locator('.guide-topbar a[href="/blog"]').click();
  await page.locator('.blog-categories a[href="/blog/category/dev-notes"]').click();assert.match(await page.locator('main').textContent(),/No articles here yet/);await capture(name+'-empty');
  await page.locator('main a[href="/blog"]').click();assert.equal(await page.locator('.blog-grid article').count(),3);
  assert.equal(await page.evaluate(()=>getComputedStyle(document.documentElement).scrollBehavior),'auto');report.cases.push(name+': native category/article/related/empty journeys, contained readable layout,44px links and reduced motion');
  const feed=await context.request.get(report.origin+'/blog/feed.xml');assert.equal(feed.status(),200);assert.match(feed.headers()['content-type'],/application\/atom\+xml/);
  const parsed=await page.evaluate(xml=>{const doc=new DOMParser().parseFromString(xml,'application/xml');return {errors:doc.getElementsByTagName('parsererror').length,entries:doc.getElementsByTagNameNS('http://www.w3.org/2005/Atom','entry').length,hidden:doc.documentElement.textContent.includes('Hidden draft fixture')};},await feed.text());
  assert.deepEqual(parsed,{errors:0,entries:3,hidden:false});report.cases.push(name+': Atom response and native XML parsing');await context.close();
 }
 assert.equal(report.pageErrors.length,0);for(const [url,p] of generated)if(report.served[url])assert.equal(report.served[url],sha(Buffer.from(p.content)));for(const [url,file] of assets)if(report.served[url])assert.equal(report.served[url],sha(fs.readFileSync(file)));
 report.passed=true;
}catch(error){report.failure=error.stack;process.exitCode=1;if(page&&!page.isClosed())try{await page.screenshot({path:path.join(out,'failure.png')});}catch{}}
finally{
 if(browser)await bounded('browser connection',()=>browser.close());if(browserServer)report.browserServerClosed=await bounded('browser server',()=>browserServer.close());if(chromeClose)await bounded('Chrome close event',()=>chromeClose);report.chromeProcessCloseObserved=chromeClosed;
 if(server){server.closeAllConnections();report.serverCloseObserved=await bounded('HTTP server',()=>new Promise(resolve=>server.close(resolve)));}if(report.cleanupErrors.length){report.passed=false;process.exitCode=1;}
 fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({passed:report.passed,cases:report.cases,chromeClosed,serverClosed:report.serverCloseObserved,failure:report.failure}));
}
