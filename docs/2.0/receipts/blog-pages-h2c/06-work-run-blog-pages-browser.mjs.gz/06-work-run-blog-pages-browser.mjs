import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import {createHash,randomUUID} from 'node:crypto';import {fileURLToPath} from 'node:url';
import {runOwnedWindowsChild} from './owned-windows-preview-child.mjs';
const work=fileURLToPath(new URL('.',import.meta.url)),repo='C:/Users/just_/lesters-arcade-wt/visual-overhaul-200',out=path.join(work,'blog-pages-window-01'),browserOut=path.join(work,'blog-pages-browser-01'),marker='C:/Users/just_/lesters-arcade-wt/.locks/heavy.lock';
const hash=file=>createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const files=['scripts/lib/blog-content.mjs','scripts/lib/blog-render.mjs','scripts/lib/blog-pages.mjs','tests/blog-pages.test.mjs','tests/blog-content.test.mjs','tests/blog-render.test.mjs','apps/portal/blog/article.css','apps/portal/how-ranked-works.css','apps/portal/src/design-tokens.css','apps/portal/assets/brand/lesters-arcade-logo-horizontal.png','apps/portal/assets/favicon.svg','build.mjs','apps/portal/main.js','scripts/build-portal-pages.mjs','apps/portal/index.html','apps/portal/sitemap.xml'];
const pins=()=>Object.fromEntries(files.map(file=>[file,hash(path.join(repo,file))]));
assert.equal(fs.existsSync(marker),false);assert.equal(fs.existsSync(out),false);assert.equal(fs.existsSync(browserOut),false);
const green=JSON.parse(fs.readFileSync(path.join(work,'blog-pages-source-green-01/report.json')));assert.ok(green.passed&&green.childrenClosed&&green.markerReleased);
for(const [file,pin] of Object.entries(green.after))assert.equal(hash(path.join(repo,file)),pin);
const token=randomUUID(),report={passed:false,before:pins(),harness:Object.fromEntries(['run-blog-pages-browser.mjs','blog-pages-browser.mjs','owned-windows-preview-child.mjs'].map(file=>[file,hash(path.join(work,file))]))};
fs.mkdirSync(out);fs.mkdirSync(marker);fs.writeFileSync(path.join(marker,'owner.json'),JSON.stringify({owner:'/root',token,task:'Static journal index category feed and article Chrome review'}));let closed=true;
function absent(pid){assert.ok(Number.isSafeInteger(pid)&&pid>0);try{process.kill(pid,0);return false;}catch(error){if(error.code==='ESRCH')return true;throw error;}}
try{
 closed=false;const command=await runOwnedWindowsChild('C:/Program Files/nodejs/node.exe',[path.join(work,'blog-pages-browser.mjs'),token],{cwd:repo,watchdogMs:90000,maxOutputBytes:1024*1024});report.command=command;
 closed=command.childClosureConfirmed&&absent(command.spawnedPid);report.childPidAbsent=closed;assert.ok(closed);assert.equal(command.normalExit,true);
 report.browser=JSON.parse(fs.readFileSync(path.join(browserOut,'report.json')));assert.equal(report.browser.passed,true);report.passed=true;
}catch(error){report.failure=error.stack;process.exitCode=1;}
finally{
 try{
  const b=JSON.parse(fs.readFileSync(path.join(browserOut,'report.json')));report.browser=b;
  closed=Boolean(closed&&b.chromeProcessCloseObserved&&b.chromeClose?.code===0&&b.chromeClose?.signal===null&&b.browserServerClosed&&b.serverCloseObserved);
  if(b.chromePid){report.chromePidAbsent=absent(b.chromePid);closed=closed&&report.chromePidAbsent;}
  if(b.origin){try{await fetch(b.origin,{signal:AbortSignal.timeout(1500)});report.httpRefused=false;}catch(error){report.httpRefused=error.cause?.code==='ECONNREFUSED';}closed=closed&&report.httpRefused;}
 }catch(error){report.cleanupInspectionFailure=error.stack;closed=false;}
 report.after=pins();try{assert.deepEqual(report.after,report.before);for(const [file,pin] of Object.entries(report.harness))assert.equal(hash(path.join(work,file)),pin);}catch(error){report.custodyFailure=error.stack;report.passed=false;process.exitCode=1;}
 report.childrenClosed=closed;if(closed){assert.equal(JSON.parse(fs.readFileSync(path.join(marker,'owner.json'))).token,token);fs.unlinkSync(path.join(marker,'owner.json'));fs.rmdirSync(marker);report.markerReleased=true;}
 else{report.passed=false;process.exitCode=1;}
 fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({passed:report.passed,cases:report.browser?.cases,childrenClosed:closed,markerReleased:report.markerReleased,failure:report.failure}));
}

