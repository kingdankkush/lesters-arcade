import fs from 'node:fs';import path from 'node:path';import http from 'node:http';import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';import {fileURLToPath,pathToFileURL} from 'node:url';
const work=fileURLToPath(new URL('.',import.meta.url)),repo='C:/Users/just_/lesters-arcade-wt/visual-overhaul-200',root=path.join(repo,'apps/portal');
const token=process.argv[2],out=path.join(work,'blog-editorial-browser-01');
assert.equal(JSON.parse(fs.readFileSync('C:/Users/just_/lesters-arcade-wt/.locks/heavy.lock/owner.json')).token,token);
assert.equal(fs.existsSync(out),false);fs.mkdirSync(out);
const {parseBlogPost}=await import(pathToFileURL(path.join(repo,'scripts/lib/blog-content.mjs')));
const {renderBlogArticle}=await import(pathToFileURL(path.join(repo,'scripts/lib/blog-render.mjs')));
const html=renderBlogArticle(parseBlogPost(fs.readFileSync(path.join(work,'blog-editorial-draft.md'),'utf8')),{preview:true});
fs.writeFileSync(path.join(out,'article.html'),html);
const {chromium}=await import(pathToFileURL(path.join(repo,'benchmarks/hmh-engine-bakeoff/node_modules/playwright/index.mjs')));
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const allowed=new Map(['/src/design-tokens.css','/how-ranked-works.css','/blog/article.css','/assets/brand/lesters-arcade-logo-horizontal.png','/assets/favicon.svg'].map(url=>[url,path.join(root,url)]));
const report={passed:false,scope:'Actual static article renderer with draft content, portal CSS and assets. Local-only HTTP preview; no public route or build activation. Phone viewport is not a physical device.',cases:[],captures:[],served:{},pageErrors:[],cleanupErrors:[]};
let server,browserServer,browser,chromeClose,chromeClosed=false,page;
async function bounded(name,fn){let timer;try{await Promise.race([fn(),new Promise((_,reject)=>timer=setTimeout(()=>reject(Error(name+' timeout')),5000))]);return true;}catch(error){report.cleanupErrors.push({name,error:error.message});return false;}finally{clearTimeout(timer);}}
async function capture(page,name){
 const metrics=await page.evaluate(()=>({width:innerWidth,height:innerHeight,scrollWidth:document.documentElement.scrollWidth,scrollY,
  title:document.querySelector('h1').getBoundingClientRect().toJSON(),textSize:getComputedStyle(document.querySelector('.blog-prose p')).fontSize,
  toc:[...document.querySelectorAll('.guide-toc a')].map(a=>({text:a.textContent,box:a.getBoundingClientRect().toJSON(),target:Boolean(document.querySelector(a.getAttribute('href')))})),
  scriptCount:document.scripts.length,logoReady:document.querySelector('.guide-brand img').naturalWidth>0,robots:document.querySelector('meta[name=robots]').content})));
 assert.ok(metrics.scrollWidth<=metrics.width);assert.equal(metrics.scriptCount,0);assert.equal(metrics.logoReady,true);assert.equal(metrics.robots,'noindex, nofollow');
 assert.ok(metrics.toc.every(link=>link.target&&link.box.height>=44));assert.ok(parseFloat(metrics.textSize)>=16);
 const file=path.join(out,name+'.png');await page.screenshot({path:file});report.captures.push({name,file,sha256:sha(fs.readFileSync(file)),metrics});
}
try{
 server=http.createServer((req,res)=>{
  try{const pathname=new URL(req.url,'http://127.0.0.1').pathname;
   const file=allowed.get(pathname),bytes=pathname==='/__blog-preview__/article.html'?Buffer.from(html):file?fs.readFileSync(file):null;
   if(!bytes){res.writeHead(404);res.end();return;}
   report.served[pathname]=sha(bytes);res.setHeader('Cache-Control','no-store');res.setHeader('Content-Type',pathname.endsWith('.css')?'text/css':pathname.endsWith('.png')?'image/png':pathname.endsWith('.svg')?'image/svg+xml':'text/html; charset=utf-8');res.end(bytes);
  }catch{res.writeHead(500);res.end();}
 });
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});report.origin='http://127.0.0.1:'+server.address().port;
 browserServer=await chromium.launchServer({executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true});report.chromePid=browserServer.process().pid;
 chromeClose=new Promise(resolve=>browserServer.process().once('close',(code,signal)=>{report.chromeClose={code,signal};chromeClosed=true;resolve();}));
 browser=await chromium.connect(browserServer.wsEndpoint());report.version=browser.version();
 for(const profile of [{name:'desktop',viewport:{width:1440,height:1000},deviceScaleFactor:1},{name:'phone',viewport:{width:414,height:896},deviceScaleFactor:3,isMobile:true,hasTouch:true}]){
  const {name,...options}=profile;
  const context=await browser.newContext({...options,serviceWorkers:'block',javaScriptEnabled:false,reducedMotion:'reduce'});
  await context.route('**/*',route=>route.request().url().startsWith(report.origin+'/')?route.continue():route.abort());
  page=await context.newPage();page.on('pageerror',error=>report.pageErrors.push(error.message));page.setDefaultTimeout(7000);
  const response=await page.goto(report.origin+'/__blog-preview__/article.html');assert.equal(response.status(),200);assert.equal(await page.locator('h1').count(),1);
  assert.equal(await page.locator('link[rel=canonical]').count(),0);assert.match(await page.locator('.blog-preview').textContent(),/Not published/);
  await capture(page,profile.name+'-top');
  if(profile.name==='desktop'){
   await page.keyboard.press('Tab');assert.equal(await page.locator('.skip-link').evaluate(a=>a===document.activeElement),true);
   await page.keyboard.press('Enter');assert.equal(await page.evaluate(()=>document.activeElement.id),'main');report.cases.push('native keyboard skip link focuses article without JavaScript');
  }
  await page.locator('.guide-toc a').filter({hasText:'Chikun'}).click();assert.equal(new URL(page.url()).hash,'#section-chikun-s-escape');
  const top=await page.locator('#section-chikun-s-escape').evaluate(el=>el.getBoundingClientRect().top);assert.ok(top>=0&&top<100);await capture(page,profile.name+'-section');
  await page.locator('.guide-toc a').filter({hasText:'Pick your next cabinet'}).click();await capture(page,profile.name+'-end');
  assert.equal(await page.evaluate(()=>getComputedStyle(document.documentElement).scrollBehavior),'auto');
  report.cases.push(profile.name+': CSS, logo, readable type, contained layout, all section targets,44px links, reduced-motion anchors and no scripts');
  await context.close();
 }
 const narrow=await browser.newContext({viewport:{width:320,height:568},javaScriptEnabled:false,serviceWorkers:'block',reducedMotion:'reduce'});
 await narrow.route('**/*',route=>route.request().url().startsWith(report.origin+'/')?route.continue():route.abort());page=await narrow.newPage();await page.goto(report.origin+'/__blog-preview__/article.html');await capture(page,'small-phone-top');await narrow.close();report.cases.push('320px layout remains contained');
 assert.equal(report.pageErrors.length,0);assert.equal(report.served['/__blog-preview__/article.html'],sha(Buffer.from(html)));
 for(const [url,file] of allowed)if(report.served[url])assert.equal(report.served[url],sha(fs.readFileSync(file)));
 report.passed=true;
}catch(error){report.failure=error.stack;process.exitCode=1;if(page&&!page.isClosed())try{await page.screenshot({path:path.join(out,'failure.png')});}catch{}}
finally{
 if(browser)await bounded('browser connection',()=>browser.close());if(browserServer)report.browserServerClosed=await bounded('browser server',()=>browserServer.close());
 if(chromeClose)await bounded('Chrome close event',()=>chromeClose);report.chromeProcessCloseObserved=chromeClosed;
 if(server){server.closeAllConnections();report.serverCloseObserved=await bounded('HTTP server',()=>new Promise(resolve=>server.close(resolve)));}
 if(report.cleanupErrors.length){report.passed=false;process.exitCode=1;}
 fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({passed:report.passed,cases:report.cases,chromeClosed,serverClosed:report.serverCloseObserved,failure:report.failure}));
}
