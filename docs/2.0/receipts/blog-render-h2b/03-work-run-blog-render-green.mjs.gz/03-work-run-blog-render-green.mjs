import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import {createHash,randomUUID} from 'node:crypto';import {fileURLToPath} from 'node:url';import {runOwnedWindowsChild} from './owned-windows-child.mjs';
const phase=process.argv[2];assert.ok(['red','green'].includes(phase));
const work=fileURLToPath(new URL('.',import.meta.url)),repo='C:/Users/just_/lesters-arcade-wt/visual-overhaul-200',out=path.join(work,'blog-render-source-'+phase+'-01'),marker='C:/Users/just_/lesters-arcade-wt/.locks/heavy.lock';
const test='tests/blog-render.test.mjs',files=new Set([test,'tests/blog-content.test.mjs','scripts/lib/blog-render.mjs']);
function closure(relative){if(!fs.existsSync(path.join(repo,relative)))return;for(const match of fs.readFileSync(path.join(repo,relative),'utf8').matchAll(/(?:from\s*|import\s*\()\s*['"](\.[^'"]+)['"]/g)){const child=path.normalize(path.join(path.dirname(relative),match[1]));assert.ok(!child.startsWith('..'));if(!files.has(child)){files.add(child);closure(child);}}}closure(test);
const sha=p=>createHash('sha256').update(fs.readFileSync(p)).digest('hex'),pins=()=>Object.fromEntries([...files].sort().map(f=>[f,fs.existsSync(path.join(repo,f))?sha(path.join(repo,f)):null]));
assert.equal(fs.existsSync(marker),false);assert.equal(fs.existsSync(out),false);fs.mkdirSync(out);const token=randomUUID(),report={phase,before:pins(),commands:[],passed:false};let closed=true;
fs.mkdirSync(marker);fs.writeFileSync(path.join(marker,'owner.json'),JSON.stringify({owner:'/root',token,task:'Blog static article focused regression'}));
const absent=pid=>{try{process.kill(pid,0);return false;}catch(e){if(e.code==='ESRCH')return true;throw e;}};
try{
 const locations=[repo];if(phase==='green'){const copy=path.join(out,'isolated');fs.mkdirSync(copy);for(const f of files){fs.mkdirSync(path.dirname(path.join(copy,f)),{recursive:true});fs.copyFileSync(path.join(repo,f),path.join(copy,f));}locations.push(copy);}
 for(const cwd of locations){closed=false;const env=cwd===repo?undefined:{SystemRoot:process.env.SystemRoot,TEMP:process.env.TEMP,TMP:process.env.TMP,PATH:''};const c=await runOwnedWindowsChild('C:/Program Files/nodejs/node.exe',['--test','--test-reporter=tap',test,'tests/blog-content.test.mjs'],{cwd,env,watchdogMs:15000,maxOutputBytes:512*1024});const pidAbsent=c.childClosureConfirmed&&absent(c.spawnedPid);report.commands.push({cwd,command:c,pidAbsent});closed=c.childClosureConfirmed&&pidAbsent;assert.ok(closed);assert.equal(c.exitCode,phase==='red'?1:0);assert.equal(c.signal,null);assert.equal(c.watchdogTriggered,false);assert.match(c.stdout,/# tests 24/);assert.match(c.stdout,phase==='red'?/# fail 10/:/# fail 0/);assert.match(c.stdout,/# skipped 0/);}
 report.after=pins();assert.deepEqual(report.after,report.before);report.passed=true;
}catch(e){report.failure=e.stack;process.exitCode=1;}finally{report.childrenClosed=closed;if(closed){assert.equal(JSON.parse(fs.readFileSync(path.join(marker,'owner.json'))).token,token);fs.unlinkSync(path.join(marker,'owner.json'));fs.rmdirSync(marker);report.markerReleased=true;}fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2));console.log(JSON.stringify({passed:report.passed,phase,childrenClosed:closed,markerReleased:report.markerReleased,failure:report.failure}));}




