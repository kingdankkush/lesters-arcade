import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
const work=fileURLToPath(new URL('.',import.meta.url));
const g=JSON.parse(fs.readFileSync(path.join(work,'world-w3d-gather.json')));
const root='C:/Users/just_/lesters-arcade-wt/visual-overhaul-200';
const sha=b=>createHash('sha256').update(b).digest('hex');
const checks=[];
for(const [kind,files] of Object.entries(g.closure))for(const [file,pin] of Object.entries(files)){
  const raw=fs.readFileSync(path.join(root,file)),actual=sha(raw);
  let basis='exact';
  if(actual!==pin.sha256){
    if(file==='build.mjs'){
      assert.equal(actual,'d970751d2c2e68c60fd4a2932656d840d1a83ffad87764fbd80fe2900e976139');
      basis='Existing root STACKED local page entries; same Git blob before/after gather d4e46132e83e7458320dc8d844c243bb71d7cff4';
    }else{
      assert.equal(kind,'sources',file);
      assert.equal(raw.toString('utf8').replaceAll('\r\n','\n'),fs.readFileSync(path.join(g.sourceRepo,file),'utf8').replaceAll('\r\n','\n'),file);
      basis='newline only';
    }
  }
  checks.push({kind,file,sha256:actual,basis});
}
for(const entry of g.changes){
  if(['docs/2.0/PROGRESS.md','scripts/syntax-check.mjs'].includes(entry.file))continue;
  const actual=sha(fs.readFileSync(path.join(root,entry.file)));
  assert.ok([entry.workingSha256,entry.committedSha256].includes(actual),entry.file);
}
const report={passed:true,sourceCommit:g.commit,gatherCommit:'9b10c5610',checks,
  retainedExistingChanges:['Both append-only progress entries','Existing syntax entries','Previously committed STACKED build entries'],
  initialAudit:'Stopped on build.mjs mismatch; examined exact diff and verified unchanged root blob before allowing this specific existing delta.',
  scope:'Source/evidence gather equivalence, not combined-root build or release certification'};
fs.writeFileSync(path.join(work,'world-w3d-root-equivalence.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({passed:true,checks:checks.length,sourceChanges:g.changes.length,exceptions:checks.filter(x=>x.basis!=='exact')}));
