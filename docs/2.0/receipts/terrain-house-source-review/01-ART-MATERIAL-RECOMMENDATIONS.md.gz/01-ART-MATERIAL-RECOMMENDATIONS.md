# Meadows material and contact audit

Read-only source audit, September 30, 2026. No source model or texture was changed.
The five inspected GLBs retain their original SHA-256 hashes. Embedded images in
this directory are byte-exact payload copies for inspection, not new runtime art.
`inventory.json` records source paths, hashes, original mesh counts and materials.

## What the references actually supply

Owner references L01 and L02 were inspected at full source size. Their strongest
features are broad, calm paths framed by much denser edges; irregular rooted tree
clusters; readable leaf/blade/stone shapes at medium scale; distinct sidewalk or
shoulder construction; and household details grouped near fences and entrances.
They do not support spreading an equally busy texture over every surface. Their
low camera and golden light are composition references, not permission to change
HMH's projection or reserved cue colours.

The current `forest-floor.png` and `road.png` were inspected. They contain largely
cloudy variation and tiny flecks, not recognisable grass, leaf or aggregate shapes.
A18's quieter spatial distribution addresses the noise, but cannot manufacture
those missing material forms by recolouring the existing maps.

## Best existing candidates

| Existing source | Useful role | Limitation / recommended treatment |
| --- | --- | --- |
| `Tripo-Level-Design-Batch-2/models/47-47-cracked-asphalt-road-section/model.glb` | Localized asphalt repair, cracked road edge or aggregate transition | Actual preview and embedded albedo show distinct cracks and aggregate. 57,960 triangles, three 4096² PBR maps. Preserve UV mapping and bake a small presentation derivative from the original geometry. Do not repeat the raw UV atlas, import the whole slab as a traversable step, or ship the three source maps. Avoid repeating its prominent hole/stripe across the road. |
| `Tripo-Level-Design-Batch-2/models/75-75-hedgerow-section/model.glb` | Garden boundary mass and sheltered base variation | Actual preview has a dense box-shaped hedge with a gap, not lawn. 96,280 triangles. Useful as a baked border prop after scale/pivot review; not as flattened generic grass. |
| `Tripo-Environment-Powerups/models/04-04-fern-cluster/model.glb` | Sparse broad understory shapes at canopy/house margins | Already reused in the current study. 76,391 triangles. Reuse source-derived variants with visible negative space; do not spread evenly over walkable terrain. |
| `Tripo-Environment-Powerups/models/01-01-broadleaf-shrub-mass/model.glb` | Low clustered foliage mass and contact shadow at sheltered edges | Already reused. 76,744 triangles. Distinguish silhouette, rotation and local height in small authored groups while preserving clear routes. |
| `Tripo-Environment-Powerups/models/10-10-rubble-daisy-patch/model.glb` | A small abandoned household/rubble detail near an existing masonry edge | Actual preview contains a concrete slab and rebar. 79,011 triangles. It is not a generic meadow patch. White/yellow petals must stay subordinate to pickup cues; no repeated bright dots across combat space. |

Each source has three 4096² images. A straightforward RGBA8 decode would be
192 MiB per model before mipmaps, approximately256 MiB with a full mip chain.
These are theoretical decoded costs, not measured resident GPU figures. They
reinforce baking/packing optimized derivatives rather than adding source GLBs to
the phone scene. A single512² RGBA8 atlas is1 MiB before mipmaps (about1.33 MiB
with them); its actual coverage, sampling and runtime residency still need proof.

## Next concrete material slice

After A18's base is reviewed, add **one** road47-derived repair/shoulder detail
beside the existing clear approach. Keep it out of the path centre, suppress the
large hole/paint-line motif where it would imply collision, and retain original
UV-based surface character instead of using its island atlas as a repeating map.
Bake to a calibrated four-metre-scale footprint initially (512 texels across gives
the draft128 texels/metre), then check its actual game sampling and alpha edges.
Use an explicit placement and seed isolated from simulation if variants are added.
No material/detail pass may add a blocker, step, hazard or run-evidence event.

Grass needs actual blade/leaf forms in sparse edge clusters. Neither current noisy
map is a sufficient final grass source. The existing broad foliage can support
those borders, but a small authored grass cluster/atlas may still be required;
reuse the current authored grass geometry as a starting point and improve blade
width, curvature, grouping and lighting instead of repeatedly increasing count.
No paid generation is needed for that model refinement.

## House and contact review

The original farmhouse preview shows readable clapboard, door, upper storey and
porch, while the current patch's porch is very dark and its roof dominates. The
native study already uses a neutral environment and a shared upper-left sun; a
global ambient boost risks flattening the improved ground and all other props.
Before changing light, compare the original imported house with its added roof
and foundation components under the **same** projection and light. Check canopy/
roof occlusion and material normal orientation. Improve local bounce/contact only
after that comparison identifies the cause; do not fake an emissive doorway.

The native study precompensates geometry for HMH's runtime sprite projection.
Its raw still alone is insufficient to judge final house/human scale. Place the
existing human at the porch approach and review the actual runtime projection,
foot grounding, doorway scale and actor occlusion before accepting the patch.
Keep the source/collider/hitbox authority unchanged. The original model preview
also uses a different framing, so it is not a matched lighting comparison.

This audit recommends candidates and experiments. It does not approve any asset
or claim an accepted game vertical slice, phone performance, or final terrain.
