"""Matched native house-component diagnostic; original source is read only."""
import hashlib
import json
import math
from pathlib import Path
import sys
import bpy
from mathutils import Matrix, Vector

source = Path(sys.argv[sys.argv.index('--') + 1])
out = Path(sys.argv[sys.argv.index('--') + 2])
expected = '720ae403c1679220243bd8ade6b80513870f63d266706365196f21ae741cc153'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(source) == expected
assert bpy.app.version[:2] == (5, 1)
out.mkdir(exist_ok=False)
bpy.ops.wm.read_factory_settings(use_empty=True)
scene = bpy.context.scene
names = ['tripo_node_dde8a168-6e7b-4e77-887d-8a90e4201fae',
         'Finished farmhouse slate roof', 'Original footprint grounded foundation']
with bpy.data.libraries.load(str(source), link=False) as (available, requested):
    assert all(name in available.objects for name in names)
    requested.objects = names
originals = requested.objects
hidden = bpy.data.collections.new('Untouched source data')
scene.collection.children.link(hidden)
hidden.hide_render = True
for ob in originals:
    if ob.parent and ob.parent.name not in hidden.objects:
        hidden.objects.link(ob.parent)
    hidden.objects.link(ob)
bpy.context.view_layer.update()

def fingerprint(ob):
    # Data, materials and modifier identity remain shared with unchanged source.
    return {'vertices': [list(v.co) for v in ob.data.vertices],
            'faces': [list(p.vertices) for p in ob.data.polygons],
            'normals': [list(n.vector) for n in ob.data.corner_normals],
            'matrix': [list(row) for row in ob.matrix_world],
            'materials': [m.as_pointer() for m in ob.data.materials]}

before = [fingerprint(ob) for ob in originals]
theta = math.radians(55)
projection = Matrix.Diagonal((1, 1, 1 / math.tan(theta), 1))
copies = []
for ob in originals:
    copy = ob.copy()
    copy.data = ob.data
    copy.parent = None
    scene.collection.objects.link(copy)
    copy.matrix_world = projection @ Matrix.Rotation(math.pi, 4, 'Z') @ ob.matrix_world
    copy.hide_render = False
    copies.append(copy)
bpy.context.view_layer.update()
points = [ob.matrix_world @ Vector(p) for ob in copies for p in ob.bound_box]
low = Vector(tuple(min(p[i] for p in points) for i in range(3)))
high = Vector(tuple(max(p[i] for p in points) for i in range(3)))
centre = (low + high) / 2
camera_data = bpy.data.cameras.new('Matched55degree')
camera_data.type = 'ORTHO'
camera = bpy.data.objects.new(camera_data.name, camera_data)
scene.collection.objects.link(camera)
scene.camera = camera
camera.rotation_euler = (theta, 0, 0)
camera.location = centre + Vector((0, -25 * math.sin(theta), 25 * math.cos(theta)))
bpy.context.view_layer.update()
projected = [camera.matrix_world.inverted() @ p for p in points]
camera.data.ortho_scale = max(max(p[i] for p in projected) - min(p[i] for p in projected) for i in [0, 1]) / .80
cx = (max(p.x for p in projected) + min(p.x for p in projected)) / 2
cy = (max(p.y for p in projected) + min(p.y for p in projected)) / 2
camera.location += camera.rotation_euler.to_matrix() @ Vector((cx, cy, 0))
bpy.ops.mesh.primitive_plane_add(size=60, location=(centre.x, centre.y, low.z - .002))
ground = bpy.context.object
material = bpy.data.materials.new('Constant neutral ground')
material.use_nodes = True
material.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value = (.18, .20, .13, 1)
material.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value = .9
ground.data.materials.append(material)
world = bpy.data.worlds.new('Same A18 neutral daylight')
world.use_nodes = True
world.node_tree.nodes['Background'].inputs[0].default_value = (.32, .34, .29, 1)
world.node_tree.nodes['Background'].inputs[1].default_value = .75
scene.world = world
sun = bpy.data.lights.new('Same A18 shared upper-left key', 'SUN')
sun.energy = 2.1
sun.color = (1, .97, .90)
sun.angle = math.radians(7)
light = bpy.data.objects.new(sun.name, sun)
scene.collection.objects.link(light)
light.location = (-5, -8, 12)
light.rotation_euler = (-light.location).to_track_quat('-Z', 'Y').to_euler()
scene.render.engine = 'CYCLES'
scene.cycles.device = 'CPU'
scene.cycles.samples = 12
scene.cycles.use_adaptive_sampling = False
scene.cycles.use_denoising = False
scene.cycles.max_bounces = 4
scene.cycles.seed = 0
scene.render.threads_mode = 'FIXED'
scene.render.threads = 2
scene.render.resolution_x = scene.render.resolution_y = 768
scene.render.resolution_percentage = 100
scene.render.image_settings.file_format = 'PNG'
scene.render.image_settings.color_mode = 'RGBA'
scene.view_settings.view_transform = 'AgX'
scene.view_settings.exposure = .15
camera_state = [list(row) for row in camera.matrix_world]
renders = []
for label, visible in [('original', (True, False, False)),
                       ('original-foundation', (True, False, True)),
                       ('full-assembly', (True, True, True))]:
    for ob, show in zip(copies, visible):
        ob.hide_render = not show
    path = out / (label + '.png')
    scene.render.filepath = str(path)
    bpy.ops.render.render(write_still=True)
    assert camera_state == [list(row) for row in camera.matrix_world]
    renders.append({'name': label, 'visible': list(visible), 'path': str(path), 'sha256': sha(path)})
assert before == [fingerprint(ob) for ob in originals]
assert sha(source) == expected
report = {'passed': True, 'scope': 'Native component diagnostic, not runtime art acceptance',
          'source': str(source), 'sourceSha256': expected, 'sourceUnchanged': True,
          'projection': '55 degrees from vertical, precompensated Z; no runtime Y expansion',
          'camera': camera_state, 'orthoScale': camera.data.ortho_scale,
          'originalBounds': {ob.name: [list(ob.matrix_world @ Vector(p)) for p in ob.bound_box] for ob in originals},
          'renders': renders, 'runtimeWritten': False}
(out / 'report.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf8')
