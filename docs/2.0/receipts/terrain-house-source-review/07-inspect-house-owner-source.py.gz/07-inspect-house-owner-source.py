"""Matched native house-component diagnostic; original source is read only."""
import hashlib
import json
import math
from pathlib import Path
import sys
import bpy
from mathutils import Matrix, Vector

source = Path(sys.argv[sys.argv.index('--') + 1])
out = Path(sys.argv[sys.argv.index('--') + 2])
expected = '720ae403c1679220243bd8ade6b80513870f63d266706365196f21ae741cc153'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(source) == expected
assert bpy.app.version[:2] == (5, 1)
out.mkdir(exist_ok=False)
bpy.ops.wm.read_factory_settings(use_empty=True)
scene = bpy.context.scene
names = ['tripo_node_dde8a168-6e7b-4e77-887d-8a90e4201fae',
         'Finished farmhouse slate roof', 'Original footprint grounded foundation']
with bpy.data.libraries.load(str(source), link=False) as (available, requested):
    assert all(name in available.objects for name in names)
    requested.objects = names
originals = requested.objects
hidden = bpy.data.collections.new('Untouched source data')
scene.collection.children.link(hidden)
hidden.hide_render = True
for ob in originals:
    if ob.parent and ob.parent.name not in hidden.objects:
        hidden.objects.link(ob.parent)
    hidden.objects.link(ob)
bpy.context.view_layer.update()

def fingerprint(ob):
    # Data, materials and modifier identity remain shared with unchanged source.
    return {'vertices': [list(v.co) for v in ob.data.vertices],
            'faces': [list(p.vertices) for p in ob.data.polygons],
            'normals': [list(n.vector) for n in ob.data.corner_normals],
            'matrix': [list(row) for row in ob.matrix_world],
            'materials': [m.as_pointer() for m in ob.data.materials]}

before = [fingerprint(ob) for ob in originals]
theta = math.radians(55)
projection = Matrix.Diagonal((1, 1, 1 / math.tan(theta), 1))
copies = []
for ob in originals:
    copy = ob.copy()
    copy.data = ob.data
    copy.parent = None
    scene.collection.objects.link(copy)
    copy.matrix_world = projection @ Matrix.Rotation(math.pi, 4, 'Z') @ ob.matrix_world
    copy.hide_render = False
    copies.append(copy)
bpy.context.view_layer.update()
points = [ob.matrix_world @ Vector(p) for ob in copies for p in ob.bound_box]
low = Vector(tuple(min(p[i] for p in points) for i in range(3)))
high = Vector(tuple(max(p[i] for p in points) for i in range(3)))
centre = (low + high) / 2
camera_data = bpy.data.cameras.new('Matched55degree')
camera_data.type = 'ORTHO'
camera = bpy.data.objects.new(camera_data.name, camera_data)
scene.collection.objects.link(camera)
scene.camera = camera
camera.rotation_euler = (theta, 0, 0)
camera.location = centre + Vector((0, -25 * math.sin(theta), 25 * math.cos(theta)))
bpy.context.view_layer.update()
projected = [camera.matrix_world.inverted() @ p for p in points]
camera.data.ortho_scale = max(max(p[i] for p in projected) - min(p[i] for p in projected) for i in [0, 1]) / .80
cx = (max(p.x for p in projected) + min(p.x for p in projected)) / 2
cy = (max(p.y for p in projected) + min(p.y for p in projected)) / 2
camera.location += camera.rotation_euler.to_matrix() @ Vector((cx, cy, 0))
bpy.ops.mesh.primitive_plane_add(size=60, location=(centre.x, centre.y, low.z - .002))
ground = bpy.context.object
material = bpy.data.materials.new('Constant neutral ground')
material.use_nodes = True
material.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value = (.18, .20, .13, 1)
material.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value = .9
ground.data.materials.append(material)
world = bpy.data.worlds.new('Same A18 neutral daylight')
world.use_nodes = True
world.node_tree.nodes['Background'].inputs[0].default_value = (.32, .34, .29, 1)
world.node_tree.nodes['Background'].inputs[1].default_value = .75
scene.world = world
sun = bpy.data.lights.new('Same A18 shared upper-left key', 'SUN')
sun.energy = 2.1
sun.color = (1, .97, .90)
sun.angle = math.radians(7)
light = bpy.data.objects.new(sun.name, sun)
scene.collection.objects.link(light)
light.location = (-5, -8, 12)
light.rotation_euler = (-light.location).to_track_quat('-Z', 'Y').to_euler()
scene.render.engine = 'CYCLES'
scene.cycles.device = 'CPU'
scene.cycles.samples = 12
scene.cycles.use_adaptive_sampling = False
scene.cycles.use_denoising = False
scene.cycles.max_bounces = 4
scene.cycles.seed = 0
scene.render.threads_mode = 'FIXED'
scene.render.threads = 2
scene.render.resolution_x = scene.render.resolution_y = 768
scene.render.resolution_percentage = 100
scene.render.image_settings.file_format = 'PNG'
scene.render.image_settings.color_mode = 'RGBA'
scene.view_settings.view_transform = 'AgX'
scene.view_settings.exposure = .15
camera_state = [list(row) for row in camera.matrix_world]
owner_source = Path('C:/Users/just_/Desktop/Projects/LestersArcade-Assets/Tripo-Level-Design-Batch-2/models/62-62-clapboard-farmhouse/model.glb')
owner_sha = 'a63251de2278f8de195776a0d9eac2304c1ad70224063f1ec87b57f491356fb8'
assert sha(owner_source) == owner_sha
prior = set(scene.objects)
bpy.ops.import_scene.gltf(filepath=str(owner_source))
added = [ob for ob in scene.objects if ob not in prior]
owner_meshes = [ob for ob in added if ob.type == 'MESH']
assert owner_meshes
for ob in added:
    assert ob.type in {'MESH', 'EMPTY'}, 'Unexpected source object type'
    if ob.parent is None:
        ob.matrix_world = Matrix.Rotation(math.pi / 2, 4, 'Z') @ ob.matrix_world
bpy.context.view_layer.update()
owner_points = [ob.matrix_world @ Vector(p) for ob in owner_meshes for p in ob.bound_box]
owner_low = Vector(tuple(min(p[i] for p in owner_points) for i in range(3)))
owner_high = Vector(tuple(max(p[i] for p in owner_points) for i in range(3)))
base = Vector(((owner_low.x + owner_high.x) / 2, (owner_low.y + owner_high.y) / 2, owner_low.z))
normalization = Matrix.Scale(6.5 / (owner_high.z - owner_low.z), 4) @ Matrix.Translation(-base)
for ob in owner_meshes:
    ob.matrix_world = normalization @ ob.matrix_world
bpy.context.view_layer.update()
normalized_bounds = [ob.matrix_world @ Vector(p) for ob in owner_meshes for p in ob.bound_box]
assert abs(max(p.z for p in normalized_bounds) - 6.5) < 1e-5
assert abs(min(p.z for p in normalized_bounds)) < 1e-5
owner_geometry = [fingerprint(ob) for ob in owner_meshes]
for ob in owner_meshes:
    ob.matrix_world = projection @ Matrix.Rotation(math.pi, 4, 'Z') @ ob.matrix_world
bpy.context.view_layer.update()
renders = []
for label, owner_visible in [('untouched-owner-geometry', True), ('existing-a5-assembly', False)]:
    for ob in owner_meshes:
        ob.hide_render = not owner_visible
    for ob in copies:
        ob.hide_render = owner_visible
    path = out / (label + '.png')
    scene.render.filepath = str(path)
    bpy.ops.render.render(write_still=True)
    assert camera_state == [list(row) for row in camera.matrix_world]
    renders.append({'name': label, 'path': str(path), 'sha256': sha(path)})
assert before == [fingerprint(ob) for ob in originals]
for ob, original_state in zip(owner_meshes, owner_geometry):
    state = fingerprint(ob)
    for key in ['vertices', 'faces', 'normals', 'materials']:
        assert state[key] == original_state[key], key
assert sha(source) == expected and sha(owner_source) == owner_sha
report = {'passed': True, 'scope': 'Native untouched-owner geometry versus A5 derivative, not runtime acceptance',
          'source': str(source), 'sourceSha256': expected, 'sourceUnchanged': True,
          'ownerSource': str(owner_source), 'ownerSha256': owner_sha, 'ownerGeometryUnchanged': True,
          'camera': camera_state, 'orthoScale': camera.data.ortho_scale,
          'ownerTriangles': sum(len(p.vertices) - 2 for ob in owner_meshes for p in ob.data.polygons),
          'retainedBodyTriangles': sum(len(p.vertices) - 2 for p in originals[0].data.polygons),
          'renders': renders, 'runtimeWritten': False,
          'note': 'First component diagnostic original label meant retained A5 body, whose upper roof was already removed. This comparison imports the complete owner GLB.'}
(out / 'report.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf8')
