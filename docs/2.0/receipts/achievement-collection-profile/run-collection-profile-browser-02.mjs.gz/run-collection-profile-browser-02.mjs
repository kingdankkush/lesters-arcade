import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash,randomUUID} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {runOwnedWindowsChild} from './owned-windows-preview-child.mjs';
const work=fileURLToPath(new URL('./',import.meta.url)),repo='C:/Users/just_/lesters-arcade-wt/visual-overhaul-200',marker='C:/Users/just_/lesters-arcade-wt/.locks/heavy.lock';
const out=path.join(work,'collection-profile-built-gate-02'),browserOut=path.join(work,'collection-profile-browser-02');
assert.equal(fs.existsSync(out),false);assert.equal(fs.existsSync(browserOut),false);assert.equal(fs.existsSync(marker),false);
// build.mjs removes only this literal generated output directory. Refuse links.
const dist=path.resolve(repo,'apps/portal/dist');assert.ok(dist.startsWith(path.resolve(repo)+path.sep));if(fs.existsSync(dist)){assert.equal(fs.lstatSync(dist).isSymbolicLink(),false);assert.equal(fs.realpathSync(dist).toLowerCase(),dist.toLowerCase());}
const files=['apps/portal/main.js','apps/portal/src/routes/official-profile-route.mjs','apps/portal/src/routes/hosted-profile-view.mjs','apps/portal/src/achievements/collection-view.mjs','apps/portal/src/achievements/collection-model.mjs','apps/portal/src/styles/achievement-collection.css','apps/portal/src/focus-keeper.mjs','tests/achievement-collection-model.test.mjs','tests/achievement-collection-view.test.mjs','tests/hosted-profile.test.mjs','build.mjs'];
const pin=file=>({file,sha256:createHash('sha256').update(fs.readFileSync(file)).digest('hex')});
const before=files.map(file=>pin(path.join(repo,file)));before.push(pin(fileURLToPath(import.meta.url)),pin(path.join(work,'collection-profile-browser-02.mjs')),pin(path.join(work,'owned-windows-preview-child.mjs')));
const green=JSON.parse(fs.readFileSync(path.join(work,'collection-profile-source-green-02/report.json')));assert.ok(green.passed&&green.markerReleased&&green.childrenClosed);for(const[file,expected]of Object.entries(green.after))assert.equal(pin(path.join(repo,file)).sha256,expected);
const token='collection-built-'+randomUUID();fs.mkdirSync(marker);fs.writeFileSync(path.join(marker,'owner.json'),JSON.stringify({owner:'/root',token,task:'Fresh build budgets and actual collection profile browser'}));fs.mkdirSync(out);
const report={scope:'Fresh local production build and synthetic-profile Chrome UI; not release certification or physical phone acceptance',before,phases:[],passed:false};let closed=true;
async function run(name,args,watchdogMs){closed=false;const command=await runOwnedWindowsChild('C:/Program Files/nodejs/node.exe',args,{cwd:repo,watchdogMs,maxOutputBytes:2*1024*1024});closed=command.childClosureConfirmed;report.phases.push({name,command});assert.ok(closed);assert.ok(command.normalExit,name+' failed');return command;}
try{
 await run('build',['build.mjs','--metafile'],60000);
 report.buildMeta=pin(path.join(dist,'meta.json'));fs.copyFileSync(path.join(dist,'meta.json'),path.join(out,'meta.json'));
 await run('browser',[path.join(work,'collection-profile-browser-02.mjs'),token],90000);
 report.browser=JSON.parse(fs.readFileSync(path.join(browserOut,'report.json')));
 assert.ok(report.browser.passed);assert.equal(report.browser.cases.length,7);report.passed=true;
}catch(error){report.failure=error.stack;process.exitCode=1;}finally{
 const command=report.phases.find(item=>item.name==='browser')?.command;
 if(command){let observed;try{observed=JSON.parse(fs.readFileSync(path.join(browserOut,'report.json')));report.browser??=observed;}catch{}
  const explicit=Number.isSafeInteger(observed?.chromePid)&&observed.chromePid>0&&observed.chromeProcessCloseObserved&&observed.chromeClose?.code===0&&observed.chromeClose?.signal===null&&observed.browserServerClosed&&observed.serverCloseObserved;
  closed=Boolean(command.childClosureConfirmed&&(explicit||(command.treeStop?.exitCode===0&&command.treeStop?.error===null)));
 }
 report.after=before.map(value=>pin(value.file));assert.deepEqual(report.after,before);report.childrenClosed=closed;
 if(closed){assert.equal(JSON.parse(fs.readFileSync(path.join(marker,'owner.json'))).token,token);fs.unlinkSync(path.join(marker,'owner.json'));fs.rmdirSync(marker);report.markerReleased=true;}else report.markerRetained=true;
 fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({passed:report.passed,cases:report.browser?.cases,captures:report.browser?.captures.length,markerReleased:report.markerReleased??false,failure:report.failure??null}));
}
