import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash,randomUUID} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {runOwnedWindowsChild} from './owned-windows-child.mjs';
const phase=process.argv[2];assert.ok(['red','green'].includes(phase));
const repo='C:/Users/just_/lesters-arcade-wt/visual-overhaul-200',work=fileURLToPath(new URL('./',import.meta.url));
const out=path.join(work,`collection-profile-source-${phase}-02`),marker='C:/Users/just_/lesters-arcade-wt/.locks/heavy.lock';
const files=['tests/achievement-collection-view.test.mjs','tests/hosted-profile.test.mjs','apps/portal/src/achievements/collection-view.mjs','apps/portal/src/achievements/collection-model.mjs','apps/portal/src/routes/official-profile-route.mjs','apps/portal/src/routes/hosted-profile-view.mjs','apps/portal/src/focus-keeper.mjs','apps/portal/main.js','tests/achievement-collection-model.test.mjs'];
const hash=file=>createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const before=Object.fromEntries(files.map(file=>[file,hash(path.join(repo,file))]));
assert.equal(fs.existsSync(marker),false);assert.equal(fs.existsSync(out),false);
const token='collection-profile-'+phase+'-'+randomUUID();fs.mkdirSync(marker);fs.writeFileSync(path.join(marker,'owner.json'),JSON.stringify({owner:'/root',token,task:'Scoped collection and existing hosted-profile tests'}));fs.mkdirSync(out);
const report={scope:'Actual source behavior; no live account, browser, gameplay or release acceptance',phase,before,passed:false};let closed=false;
try{
 const command=await runOwnedWindowsChild('C:/Program Files/nodejs/node.exe',['--test','--test-reporter=tap',...files.slice(0,2),'tests/achievement-collection-model.test.mjs'],{cwd:repo,watchdogMs:20000,maxOutputBytes:2*1024*1024});report.command=command;closed=command.childClosureConfirmed;
 const counts=Object.fromEntries(['tests','pass','fail','skipped','cancelled'].map(key=>[key,Number(command.stdout.match(new RegExp('^# '+key+' (\\d+)$','m'))?.[1])]));report.counts=counts;
 assert.ok(closed);assert.equal(counts.fail,phase==='red'?1:0);assert.equal(counts.skipped,0);assert.equal(counts.cancelled,0);assert.equal(command.exitCode,phase==='red'?1:0);assert.equal(counts.pass+counts.fail,counts.tests);report.passed=true;
}catch(error){report.failure=error.stack;process.exitCode=1;}finally{
 report.after=Object.fromEntries(files.map(file=>[file,hash(path.join(repo,file))]));assert.deepEqual(report.after,before);report.childrenClosed=closed;
 if(closed){assert.equal(JSON.parse(fs.readFileSync(path.join(marker,'owner.json'))).token,token);fs.unlinkSync(path.join(marker,'owner.json'));fs.rmdirSync(marker);report.markerReleased=true;}
 fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({passed:report.passed,counts:report.counts,childrenClosed:closed,markerReleased:report.markerReleased??false,failure:report.failure??null}));
}
