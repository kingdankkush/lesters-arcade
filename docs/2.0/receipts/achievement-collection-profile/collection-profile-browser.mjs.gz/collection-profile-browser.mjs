import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {fileURLToPath,pathToFileURL} from 'node:url';
const work=fileURLToPath(new URL('./',import.meta.url)),repo='C:/Users/just_/lesters-arcade-wt/visual-overhaul-200',portal=path.join(repo,'apps/portal');
const out=path.join(work,'collection-profile-browser-01'),token=process.argv[2];
assert.equal(JSON.parse(fs.readFileSync('C:/Users/just_/lesters-arcade-wt/.locks/heavy.lock/owner.json')).token,token);assert.equal(fs.existsSync(out),false);fs.mkdirSync(out);
const {chromium}=await import(pathToFileURL(path.join(repo,'benchmarks/hmh-engine-bakeoff/node_modules/playwright/index.mjs')));
const {catalogFor}=await import(pathToFileURL(path.join(repo,'apps/portal/src/achievements/index.mjs')));
const games=['lester-blaster','chikun','stacked'],wallet='0x'+'ab'.repeat(20);
const catalog=Object.fromEntries(games.map(game=>[game,catalogFor(game).filter(row=>row.available)]));
const unlocks=games.flatMap(game=>catalog[game].slice(0,3).map(row=>({id:row.id,gameId:game,unlockedAt:'2026-09-29T12:00:00.000Z',tokenId:null,mintTxHash:null})));
const gameData=Object.fromEntries(games.map(game=>[game,{rankedRuns:4,confirmedRuns:4,bestScore:20000,ranks:{weekly:3,monthly:5,allTime:12},totals:{},bests:{},lastPlayedAt:'2026-09-29T12:00:00.000Z'}]));
const profile={ok:true,wallet,profile:{displayName:'Collection QA',avatarUri:'lestersarcade:avatar/chikun',hidden:false},games:gameData,recentSessions:[],achievements:unlocks,preferences:null,updatedAt:'2026-09-29T12:00:00.000Z'};
const report={scope:'Actual locally built portal in Windows Chrome; synthetic public profile/population only. Phone viewport is not physical iPhone acceptance. No writes, wallet connection, grants, chain action or production deployment.',passed:false,cases:[],captures:[],metrics:[],pageErrors:[],cleanupErrors:[],served:{},apiRequests:[]};
const save=()=>fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2)+'\n');
const hash=b=>createHash('sha256').update(b).digest('hex');
let server,browserServer,browser,chromeClosed=false,chromeClosePromise,origin,holdPopulation=true,malformed=false;const held=[];
const json=(res,value)=>{res.setHeader('Content-Type','application/json');res.setHeader('Cache-Control','no-store');res.end(JSON.stringify(value));};
const release=()=>{holdPopulation=false;for(const callback of held.splice(0))callback();};
const suffix={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.json':'application/json','.css':'text/css','.svg':'image/svg+xml','.png':'image/png','.webp':'image/webp','.woff2':'font/woff2'};
async function bounded(name,fn){let timer;try{await Promise.race([fn(),new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error(name+' closure timeout')),5000);})]);return true;}catch(error){report.cleanupErrors.push({name,error:error.message});return false;}finally{clearTimeout(timer);}}
async function enter(context,search=''){
 const page=await context.newPage();page.setDefaultTimeout(12000);page.on('pageerror',error=>report.pageErrors.push(error.message));
 await page.goto(origin+`/profile/${wallet}${search}`,{waitUntil:'domcontentloaded'});
 const guest=page.locator('#officialGuestEnterButton');if(await guest.isVisible())await guest.click();
 await page.locator('.profile-hero-name').waitFor();return page;
}
async function capture(page,name){
 const file=path.join(out,name+'.png');await page.screenshot({path:file,fullPage:true});const bytes=fs.readFileSync(file);report.captures.push({name,file,bytes:bytes.length,sha256:hash(bytes),width:bytes.readUInt32BE(16),height:bytes.readUInt32BE(20)});
 const metrics=await page.locator('.achievement-collection-v1').evaluate(card=>({scrollWidth:document.documentElement.scrollWidth,viewport:innerWidth,cardWidth:card.getBoundingClientRect().width,controls:[...card.querySelectorAll('input,select')].map(el=>({width:el.getBoundingClientRect().width,height:el.getBoundingClientRect().height})),background:getComputedStyle(card).backgroundColor,visibleBadges:card.querySelectorAll('.collection-badge').length}));
 assert.ok(metrics.scrollWidth<=metrics.viewport,'no horizontal page overflow');assert.ok(metrics.controls.every(item=>item.height>=44));assert.equal(metrics.background,'rgb(16, 29, 35)');report.metrics.push({name,...metrics});save();
}
try{
 server=http.createServer((req,res)=>{const url=new URL(req.url,'http://127.0.0.1');
  if(url.pathname.startsWith('/api/')){report.apiRequests.push({path:url.pathname,query:url.search,method:req.method,hasAuthorization:Boolean(req.headers.authorization)});if(req.method!=='GET'){res.writeHead(405);return res.end();}
   if(url.pathname==='/api/profile')return json(res,profile);
   if(url.pathname==='/api/achievements/stats'){const game=url.searchParams.get('game');const send=()=>json(res,malformed?{ok:true,gameId:game,cohort:'wrong'}:{ok:true,gameId:game,cohort:'verified-ranked-all-time',minimumPlayers:20,rankedPlayers:100,achievements:catalog[game].map((row,i)=>({id:row.id,unlockedPlayers:1+(i%20)*4}))});if(holdPopulation)held.push(send);else send();return;}
   return json(res,{ok:true,rows:[],games:[],status:'healthy'});
  }
  try{if(url.pathname==='/favicon.ico'){res.writeHead(204);return res.end();}let file=path.resolve(portal,'.'+decodeURIComponent(url.pathname));assert.ok(file.startsWith(portal+path.sep)||file===portal);
   if(url.pathname.startsWith('/profile/'))file=path.join(portal,'index.html');else if(fs.statSync(file).isDirectory())file=path.join(file,'index.html');
   const bytes=fs.readFileSync(file);report.served[file]={bytes:bytes.length,sha256:hash(bytes)};res.setHeader('Cache-Control','no-store');res.setHeader('Content-Type',suffix[path.extname(file)]??'application/octet-stream');res.end(bytes);
  }catch{res.writeHead(404);res.end();}
 });
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});origin='http://127.0.0.1:'+server.address().port;report.origin=origin;
 browserServer=await chromium.launchServer({executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true});report.chromePid=browserServer.process().pid;chromeClosePromise=new Promise(resolve=>browserServer.process().once('close',(code,signal)=>{chromeClosed=true;report.chromeClose={code,signal};resolve();}));browser=await chromium.connect(browserServer.wsEndpoint());report.browserVersion=browser.version();
 const desktop=await browser.newContext({viewport:{width:1440,height:1000},serviceWorkers:'block'});
 const page=await enter(desktop,'?achievementCollection=collection-v1');await page.locator('.collection-badge').first().waitFor();assert.equal(await page.locator('.collection-badge').count(),124);
 const toggle=page.locator('.collection-badge[data-game="chikun"]').first().locator('summary');await toggle.click();await toggle.focus();release();await page.waitForFunction(()=>document.querySelector('.collection-population-note')?.textContent.includes('snapshot'));
 assert.equal(await page.locator('.collection-badge[data-game="chikun"]').first().locator('details').evaluate(el=>el.open),true);assert.equal(await page.evaluate(()=>document.activeElement?.dataset.game),'chikun');report.cases.push('delayed population keeps requirement and keyboard focus');
 await page.locator('[data-collection-control="filter"]').selectOption('unlocked');assert.equal(await page.locator('.collection-badge').count(),9);await capture(page,'desktop-owned');
 await page.locator('[data-collection-control="game"]').selectOption('chikun');assert.equal(await page.locator('.collection-badge').count(),3);await page.locator('[data-collection-control="search"]').fill('no-such-achievement');await page.locator('.collection-empty').waitFor();report.cases.push('game ownership and search filters');
 await page.evaluate(()=>{window.dispatchEvent(new PageTransitionEvent('pagehide',{persisted:true}));window.dispatchEvent(new PageTransitionEvent('pageshow',{persisted:true}));});await page.locator('.collection-badge').first().waitFor();await page.waitForFunction(()=>document.querySelector('.collection-population-note')?.textContent.includes('snapshot'));assert.equal(await page.locator('.collection-badge-owned').count(),9);report.cases.push('page lifecycle disposal and restored controller');
 await desktop.close();
 const phone=await browser.newContext({viewport:{width:414,height:896},deviceScaleFactor:2,hasTouch:true,isMobile:true,reducedMotion:'reduce',serviceWorkers:'block'});
 const mobile=await enter(phone,'?achievementCollection=collection-v1');await mobile.locator('.collection-badge').first().waitFor();await mobile.waitForFunction(()=>document.querySelector('.collection-population-note')?.textContent.includes('snapshot'));await mobile.locator('[data-collection-control="filter"]').selectOption('unlocked');await capture(mobile,'phone-owned');
 const animations=await mobile.locator('.achievement-collection-v1').evaluate(card=>[card,...card.querySelectorAll('*')].filter(el=>getComputedStyle(el).animationName!=='none').length);assert.equal(animations,0);report.cases.push('phone framing touch-size controls and reduced motion');await phone.close();
 for(const query of['','?achievementCollection=collection-v1&achievementCollection=collection-v1']){const ctx=await browser.newContext({serviceWorkers:'block'}),requests=[];ctx.on('request',req=>requests.push(req.url()));const p=await enter(ctx,query);await p.locator('.profile-achievement-card').first().waitFor();assert.equal(await p.locator('.achievement-collection-v1').count(),0);assert.equal(requests.filter(url=>/collection-view|achievement-collection\.css|\/api\/achievements\/stats/.test(url)).length,0);report.cases.push(query?'duplicate option stays off':'default profile stays lazy');await ctx.close();}
 malformed=true;const ctx=await browser.newContext({serviceWorkers:'block'}),bad=await enter(ctx,'?achievementCollection=collection-v1');await bad.waitForFunction(()=>document.querySelector('.collection-population-note')?.textContent.includes('unavailable'));assert.equal(await bad.locator('.collection-badge-owned').count(),9);assert.equal(await bad.locator('.collection-rarity').count(),0);report.cases.push('malformed population preserves earned badges');await ctx.close();
 assert.equal(report.pageErrors.length,0);assert.ok(report.apiRequests.every(req=>req.method==='GET'&&!req.hasAuthorization));for(const[file,pin]of Object.entries(report.served))assert.equal(hash(fs.readFileSync(file)),pin.sha256);report.passed=true;
}catch(error){report.failure=error.stack;process.exitCode=1;}finally{
 release();if(browser)report.connectionClosed=await bounded('browser connection',()=>browser.close());if(browserServer)report.browserServerClosed=await bounded('Chrome server',()=>browserServer.close());if(browserServer&&!chromeClosed)await bounded('Chrome process',()=>chromeClosePromise);report.chromeProcessCloseObserved=chromeClosed;
 if(server)report.serverCloseObserved=await bounded('HTTP server',()=>new Promise((resolve,reject)=>{server.close(error=>error?reject(error):resolve());server.closeAllConnections();}));if(report.cleanupErrors.length){report.passed=false;process.exitCode=1;}save();console.log(JSON.stringify({passed:report.passed,cases:report.cases,captures:report.captures.length,chromeClosed,serverClosed:report.serverCloseObserved,failure:report.failure??null}));
}
