// Bounded use of the existing owned-child finalizer; one test file only.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { randomUUID, createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { runOwnedWindowsChild } from './owned-windows-child.mjs';
const phase = process.argv[2]; assert.ok(['red', 'green'].includes(phase));
const repo = 'C:/Users/just_/lesters-arcade-wt/visual-overhaul-200';
const work = fileURLToPath(new URL('./', import.meta.url));
const marker = 'C:/Users/just_/lesters-arcade-wt/.locks/heavy.lock';
const out = path.join(work, 'stacked-local-import-guard-' + phase + '-01'), token = randomUUID();
const suite = 'tests/stacked-versus-table.test.mjs';
const hash = f => createHash('sha256').update(fs.readFileSync(f)).digest('hex');
assert.equal(hash(path.join(repo, suite)), hash(path.join(work, 'stacked-versus-table-' + phase + '.test.mjs')));
assert.equal(fs.existsSync(marker), false); assert.equal(fs.existsSync(out), false);
const files = new Set([suite, 'package.json', 'node_modules/acorn/package.json', 'node_modules/acorn/dist/acorn.mjs']);
function collect(directory) {
  for (const entry of fs.readdirSync(path.join(repo, directory), { withFileTypes: true })) {
    const f = directory + '/' + entry.name;
    if (f === 'apps/portal/dist') continue;
    if (entry.isSymbolicLink()) throw new Error('Unexpected source junction: ' + f);
    if (entry.isDirectory()) collect(f);
    else if (/\.[cm]?js$/.test(f)) files.add(f);
  }
}
['apps', 'server', 'api', 'sdk', 'scripts'].forEach(collect);
const pins = () => Object.fromEntries([...files].sort().map(f => [f, hash(path.join(repo, f))]));
const report = { phase, runnerSha256: hash(fileURLToPath(import.meta.url)), finalizerSha256: hash(path.join(work, 'owned-windows-child.mjs')), before: pins(), commands: [], passed: false };
fs.mkdirSync(marker); fs.writeFileSync(path.join(marker, 'owner.json'), JSON.stringify({ owner: '/root/character_resume', token, task: 'STACKED isolated local import guard source' }));
fs.mkdirSync(out); let closed = true;
async function run(cwd, env) {
  closed = false;
  const c = await runOwnedWindowsChild('C:/Program Files/nodejs/node.exe', ['--test', '--test-reporter=tap', '--test-concurrency=1', suite], { cwd, env, watchdogMs: 30000 });
  closed = c.childClosureConfirmed; report.commands.push(c); assert.ok(closed);
  const counts = Object.fromEntries(['tests', 'pass', 'fail', 'skipped', 'cancelled'].map(k => [k, Number(c.stdout.match(new RegExp('^# ' + k + ' (\\d+)$', 'm'))?.[1])]));
  assert.deepEqual(counts, { tests: 15, pass: phase === 'red' ? 8 : 15, fail: phase === 'red' ? 7 : 0, skipped: 0, cancelled: 0 });
  assert.equal(c.exitCode, phase === 'red' ? 1 : 0);
  assert.equal(c.watchdogTriggered, false); assert.equal(c.signal, null);
  if (phase === 'red') assert.equal((c.stdout.match(/error: 'localVersusImportViolations is not defined'/g) ?? []).length, 5);
  return counts;
}
try {
  report.counts = await run(repo, process.env);
  if (phase === 'green') {
    const copy = path.join(out, 'copy');
    for (const f of files) {
      fs.mkdirSync(path.dirname(path.join(copy, f)), { recursive: true });
      fs.copyFileSync(path.join(repo, f), path.join(copy, f));
      assert.equal(hash(path.join(copy, f)), report.before[f]);
    }
    assert.equal(fs.existsSync(path.join(copy, '.git')), false);
    report.copyScope = 'Exact authored JS sources and the existing Acorn package.json/ESM file; no Git, asset binaries, install or dependency junction';
    report.copyCounts = await run(copy, { ...process.env, PATH: '' });
  }
  report.passed = true;
} catch (error) { report.failure = error.stack; process.exitCode = 1; }
finally {
  report.after = pins(); report.sourceUnchanged = JSON.stringify(report.before) === JSON.stringify(report.after);
  report.childrenClosed = closed;
  if (closed) {
    assert.equal(JSON.parse(fs.readFileSync(path.join(marker, 'owner.json'))).token, token);
    fs.unlinkSync(path.join(marker, 'owner.json')); fs.rmdirSync(marker); report.markerReleased = true;
  }
  if (!report.sourceUnchanged) { report.passed = false; process.exitCode = 1; }
  fs.writeFileSync(path.join(out, 'report.json'), JSON.stringify(report, null, 2) + '\n');
  console.log(JSON.stringify({ passed: report.passed, counts: report.counts, copy: report.copyCounts, closed, markerReleased: report.markerReleased, failure: report.failure }));
}
