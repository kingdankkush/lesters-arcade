from pathlib import Path
r=Path('C:/Users/just_/lesters-arcade-wt/visual-overhaul-200')
p=r/'apps/stacked/src/local-app.mjs'
s=p.read_text()
old="layout=localBoardLayout(w,h);views.forEach"
new="layout=localBoardLayout(w,h);$('resume').disabled=!layout.playable;$('resume').textContent=layout.playable?'Resume match':'Rotate to resume';views.forEach"
assert old in s
p.write_text(s.replace(old,new))
w=Path(__file__).parent
s=(w/'stacked-local-play-browser-05.mjs').read_text().replace("+'-05'", "+'-06'")
old="await capture(page,'small-phone-setup');"
new=old+"report.smallSetupScroll=await page.locator('#panel').evaluate(el=>({clientHeight:el.clientHeight,scrollHeight:el.scrollHeight,overflow:getComputedStyle(el).overflowY}));assert.ok(report.smallSetupScroll.scrollHeight>report.smallSetupScroll.clientHeight);assert.equal(report.smallSetupScroll.overflow,'auto');await page.locator('#panel').evaluate(el=>el.scrollTop=el.scrollHeight);assert.equal(await page.locator('#start').isVisible(),true);await capture(page,'small-phone-setup-bottom');await page.locator('#panel').evaluate(el=>el.scrollTop=0);"
assert old in s
s=s.replace(old,new).replace("report.cases.push('pause controls display two readable player guides');", "await capture(page,'desktop-controls');report.cases.push('pause controls display two readable player guides');")
(w/'stacked-local-play-browser-06.mjs').write_text(s)
s=(w/'run-stacked-local-play-04.mjs').read_text().replace("+'-04'", "+'-06'").replace('play-04.mjs','play-06.mjs').replace('browser-04.mjs','browser-06.mjs')
(w/'run-stacked-local-play-06.mjs').write_text(s)
