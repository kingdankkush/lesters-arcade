from pathlib import Path
w=Path(__file__).parent
s=(w/'stacked-local-play-browser-06.mjs').read_text(encoding='utf-8').replace("+'-06'", "+'-07'")
old="'portrait must disable the unavailable Resume action');await page.locator('#resume').click();"
assert old in s
s=s.replace(old,"'portrait must disable the unavailable Resume action');")
(w/'stacked-local-play-browser-07.mjs').write_text(s,encoding='utf-8')
s=(w/'run-stacked-local-play-05.mjs').read_text(encoding='utf-8').replace("+'-05'", "+'-07'").replace('play-05.mjs','play-07.mjs').replace('browser-05.mjs','browser-07.mjs').replace('play-green-04/report.json','play-green-06/report.json')
(w/'run-stacked-local-play-07.mjs').write_text(s,encoding='utf-8')
