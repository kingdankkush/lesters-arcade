import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash,randomUUID}from'node:crypto';
import {pathToFileURL,fileURLToPath}from'node:url';
import {runOwnedWindowsChild}from'./owned-windows-child.mjs';
const repo='C:/Users/just_/lesters-arcade-wt/visual-overhaul-200',marker='C:/Users/just_/lesters-arcade-wt/.locks/heavy.lock';
const out=path.resolve('work/chikun-obstacle-game-gate-01'),browserOut=path.resolve('work/chikun-obstacle-browser-01');
assert.equal(fs.existsSync(out),false);assert.equal(fs.existsSync(browserOut),false);assert.equal(fs.existsSync(marker),false);
const pin=file=>{const bytes=fs.readFileSync(file);return{file,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')};};
const files=['apps/chikun/src/main.mjs','apps/chikun/src/ground-world.mjs','apps/chikun/src/obstacle-loop.mjs','apps/chikun/src/obstacle-loop-view.mjs','apps/chikun/src/obstacle-loop-bootstrap.mjs','apps/portal/main.js','apps/portal/src/chikun-host.mjs','apps/portal/src/chikun-presentation-switch.mjs','scripts/lib/chikun_obstacle_loop_pack.py','scripts/lib/chikun_native_transforms.py','scripts/chikun-blender/render-chikun-eagle-loop.py','tests/chikun-obstacle-loop.test.mjs','tests/chikun-obstacle-view.test.mjs','tests/chikun-obstacle-host-draw.test.mjs','tests/chikun-native-transforms.test.py','tests/chikun-native-render-cleanup.test.py','tests/chikun-obstacle-loop-pack.test.py','apps/portal/src/chikun-cabinet.mjs','apps/portal/src/chikun-ground-course.mjs','apps/portal/src/chikun-ground-runtime.mjs','apps/portal/src/chikun-ground-v3-runtime.mjs','apps/portal/src/chikun-ground-v5-runtime.mjs','apps/portal/src/chikun-bridge-protocol.mjs','server/verify/chikun.mjs','tests/fixtures/chikun-v6-replays.json','apps/chikun/assets/source/ground-sky/eagle.blend','apps/portal/assets/generated/chikun-ground-props-v1/eagle.webp','build.mjs','package.json','package-lock.json','scripts/syntax-check.mjs'];
const nativeDir=path.join(repo,'.tmp/chikun-obstacle-loop/eagle-render-v2');files.push('.tmp/chikun-obstacle-loop/eagle-render-v2/native-receipt.json',...Array.from({length:8},(_,i)=>`.tmp/chikun-obstacle-loop/eagle-render-v2/${String(i).padStart(2,'0')}.png`));
const before=files.map(file=>pin(path.join(repo,file)));before.push(pin(fileURLToPath(import.meta.url)),pin(path.resolve('work/chikun-obstacle-browser.mjs')),pin(path.resolve('work/owned-windows-child.mjs')));
const token='chikun-obstacle-game-'+randomUUID();fs.mkdirSync(marker);fs.writeFileSync(path.join(marker,'owner.json'),JSON.stringify({owner:'/root',token,task:'One private native Eagle atlas/focused/build/browser gate'}));fs.mkdirSync(out);
const report={scope:'Default-off animation pipeline candidate and private placeholder atlas; no source save, gameplay/verifier change, production art admission, physical performance or release claim',before,phases:[],passed:false,artAccepted:false,runtimeArtAdmission:false};let closed=true;
const save=()=>fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2)+'\n');
async function run(phase,program,args,watchdogMs){closed=false;report.pending=phase;save();const command=await runOwnedWindowsChild(program,args,{cwd:repo,env:{...process.env,PYTHONDONTWRITEBYTECODE:'1'},watchdogMs,maxOutputBytes:4*1024*1024});closed=command.childClosureConfirmed;report.phases.push({phase,command});report.pending=null;save();assert.ok(closed);assert.ok(command.normalExit,phase+' failed; keep output without retry');return command;}
try{
 const python='C:/Users/just_/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe',node='C:/Program Files/nodejs/node.exe';
 const packCode=String.raw`import sys,json,hashlib
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'scripts/lib'))
from chikun_obstacle_loop_pack import pack_obstacle_loop
native=root/'.tmp/chikun-obstacle-loop/eagle-render-v2';record=json.loads((native/'native-receipt.json').read_bytes())
assert record['completed'] and record['restored'] and record['meshIdentityBefore']==record['meshIdentityAfter']
assert hashlib.sha256((root/record['source']).read_bytes()).hexdigest()==record['sourceSha256']==record['sourceSha256After']
assert len(record['frames'])==8
files=[]
for index,frame in enumerate(record['frames']):
 assert frame['frame']==index and frame['file']==f'{index:02}.png'
 file=native/frame['file'];raw=file.read_bytes();assert len(raw)==frame['bytes'] and hashlib.sha256(raw).hexdigest()==frame['sha256'];files.append(file)
result=pack_obstacle_loop(files,root/'.tmp/chikun-obstacle-loop/eagle-packed-v1','eagle')
print(json.dumps({'tiers':result['tiers'],'registration':result['registration']}))
`;
 const pack=await run('native-three-tier-pack',python,['-c',packCode],30000);report.pack=JSON.parse(pack.stdout.trim());save();
 const tests=['chikun-obstacle-loop','chikun-obstacle-view','chikun-obstacle-host-draw','chikun-coin-feedback','chikun-vfx-presentation','chikun-audio','chikun-runtime-shell','chikun-polish','chikun-sim-identity','chikun-evidence-v6','server-verify-chikun','chikun-host'];
 await run('related-cosmetic-and-replay-tests',node,['--test','--test-concurrency=1',...tests.map(name=>'tests/'+name+'.test.mjs')],30000);
 const pyCode="import subprocess,sys\nfor file in sys.argv[1:]:\n result=subprocess.run([sys.executable,file],check=False)\n if result.returncode:sys.exit(result.returncode)\n";
 await run('native-pack-cleanup-regressions',python,['-c',pyCode,'tests/chikun-obstacle-loop-pack.test.py','tests/chikun-native-transforms.test.py','tests/chikun-native-render-cleanup.test.py'],10000);
 await run('fresh-normal-build',node,['build.mjs','--metafile'],120000);
 const meta=JSON.parse(fs.readFileSync(path.join(repo,'apps/portal/dist/meta.json'))),{sumStaticChunkBytes}=await import(pathToFileURL(path.join(repo,'scripts/hmh-reboot-bundle-budget.mjs')));report.budgets={};
 for(const [game,vendor,cap]of[['hmh-reboot','apps/portal/dist/chunks/hmh-pixi.js',1048576],['stacked','apps/portal/dist/stacked/stacked-pixi-v1.js',607000]]){const entry='apps/portal/dist/'+game+'/game.js',graph=sumStaticChunkBytes({metafile:meta,entryOutput:entry}),actual=[...new Set([entry,...graph.chunks.map(value=>value.path),vendor])].map(file=>pin(path.join(repo,file)));const bytes=actual.reduce((sum,value)=>sum+value.bytes,0);assert.ok(bytes<=cap);report.budgets[game]={bytes,cap,headroom:cap-bytes,files:actual};}
 const built=Object.keys(meta.outputs).map(file=>pin(path.join(repo,file)));report.builtBefore=built;save();
 const browser=await run('actual-chrome-private-atlas-browser',node,[path.resolve('work/chikun-obstacle-browser.mjs'),token],120000);
 const browserReport=JSON.parse(fs.readFileSync(path.join(browserOut,'report.json')));report.browser=browserReport;const explicit=browserReport.chromeProcessCloseObserved===true&&browserReport.browserServerClosed===true&&browserReport.serverCloseObserved===true;if(!explicit)closed=false;assert.ok(explicit&&browserReport.passed);
 report.builtAfter=built.map(value=>pin(value.file));assert.deepEqual(report.builtAfter,built);report.after=before.map(value=>pin(value.file));assert.deepEqual(report.after,before);report.passed=true;
}catch(error){report.failure=error.stack;process.exitCode=1;}
finally{
 // A failed Node parent does not alone prove browser descendants closed.
 if(report.phases.some(value=>value.phase==='actual-chrome-private-atlas-browser')){const browser=report.phases.find(value=>value.phase==='actual-chrome-private-atlas-browser').command;let observed=null;try{observed=JSON.parse(fs.readFileSync(path.join(browserOut,'report.json')));}catch{}report.browser??=observed;const explicit=observed?.chromeProcessCloseObserved===true&&observed?.browserServerClosed===true&&observed?.serverCloseObserved===true;const stopped=browser.childClosureConfirmed&&browser.treeStop?.exitCode===0&&browser.treeStop?.error===null;closed=closed&&(explicit||stopped);}
 try{report.after=before.map(value=>pin(value.file));assert.deepEqual(report.after,before);}catch(error){report.custodyFailure=error.stack;report.passed=false;process.exitCode=1;}
 report.childrenClosed=closed;if(closed){assert.equal(JSON.parse(fs.readFileSync(path.join(marker,'owner.json'))).token,token);fs.unlinkSync(path.join(marker,'owner.json'));fs.rmdirSync(marker);report.markerReleased=true;}else report.markerRetained=true;report.finishedAt=new Date().toISOString();save();console.log(JSON.stringify({passed:report.passed,markerReleased:report.markerReleased??false,budgets:report.budgets,failure:report.failure??null}));
}
