import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash,randomUUID} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {runOwnedWindowsChild} from './owned-windows-preview-child.mjs';
const work=fileURLToPath(new URL('./',import.meta.url));
const repo='C:/Users/just_/lesters-arcade-wt/visual-overhaul-200';
const marker='C:/Users/just_/lesters-arcade-wt/.locks/heavy.lock';
const out=path.join(work,'chikun-obstacle-game-gate-04');
const browserOut=path.join(work,'chikun-obstacle-portal-01');
const browserScript=path.join(work,'chikun-obstacle-portal-01.mjs');
const pin=file=>{const bytes=fs.readFileSync(file);return{file,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')};};
const previousFile=path.join(work,'chikun-obstacle-game-gate-03/report.json');
const previousBrowserFile=path.join(work,'chikun-obstacle-browser-02/report.json');
const previous=JSON.parse(fs.readFileSync(previousFile));
const previousBrowser=JSON.parse(fs.readFileSync(previousBrowserFile));
assert.equal(previous.passed,false);assert.equal(previous.markerReleased,true);assert.equal(previous.childrenClosed,true);
assert.equal(previous.reusedFreshBuild.phase,'fresh-normal-build');assert.equal(previous.reusedFreshBuild.command.normalExit,true);
assert.equal(previous.command.exitCode,1);assert.ok(previousBrowser.failure.includes("Cannot read properties of null (reading 'dataset')"));
assert.equal(previousBrowser.cases.length,6);assert.equal(previousBrowser.safety.length,1);
assert.ok(previousBrowser.cases.every(value=>value.exactReplay&&value.disposed&&value.evidenceSha256===previousBrowser.cases[0].evidenceSha256));
assert.equal(previousBrowser.chromeProcessCloseObserved,true);assert.equal(previousBrowser.chromeClose.code,0);assert.equal(previousBrowser.browserServerClosed,true);assert.equal(previousBrowser.serverCloseObserved,true);
assert.equal(previousBrowser.errors.length,0);assert.equal(previousBrowser.cleanupErrors.length,0);
for(const expected of [...previous.before,...previous.builtBefore,...previous.privateAtlasBefore])assert.deepEqual(pin(expected.file),expected,'Reused source/build/private atlas changed');
assert.equal(fs.existsSync(out),false);assert.equal(fs.existsSync(browserOut),false);assert.equal(fs.existsSync(marker),false);
const before=[...previous.before,pin(fileURLToPath(import.meta.url)),pin(browserScript),pin(previousFile),pin(previousBrowserFile)];
const token='chikun-obstacle-portal-01-'+randomUUID();
fs.mkdirSync(marker);fs.writeFileSync(path.join(marker,'owner.json'),JSON.stringify({owner:'/root',token,task:'Portal-only load-race harness correction; unchanged source/build/private atlas'}));fs.mkdirSync(out);
const report={scope:'ONE native portal-only smoke with null-safe load wait; reuses exact checked source/build/private atlas and six actual identical replay cases plus disposal witness; no native/render/repack/tests/build/phone/production art acceptance',before,reusedPassedPhases:previous.reusedPassedPhases,reusedFreshBuild:previous.reusedFreshBuild,reusedBrowserCases:previousBrowser.cases,reusedBrowserSafety:previousBrowser.safety,budgets:Object.fromEntries(Object.entries(previous.budgets).map(([game,value])=>[game,{bytes:value.bytes,cap:value.cap,headroom:value.headroom}])),builtBefore:previous.builtBefore,privateAtlasBefore:previous.privateAtlasBefore,fixtureSeed:2416520887,priorFailurePins:[pin(previousFile),pin(previousBrowserFile)],passed:false,runtimeArtAdmission:false,artAccepted:false};
const save=()=>fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2)+'\n');
let closed=true,command;
try{
 save();closed=false;command=await runOwnedWindowsChild('C:/Program Files/nodejs/node.exe',[browserScript,token],{cwd:repo,env:{...process.env,PYTHONDONTWRITEBYTECODE:'1'},watchdogMs:120000,maxOutputBytes:1024*1024});report.command=command;
 const observed=JSON.parse(fs.readFileSync(path.join(browserOut,'report.json')));report.browser=observed;
 const explicit=observed.chromeProcessCloseObserved===true&&observed.chromeClose?.code===0&&observed.browserServerClosed===true&&observed.serverCloseObserved===true;
 closed=command.childClosureConfirmed&&explicit;assert.ok(closed,'actual Chrome and HTTP closure required');assert.ok(command.normalExit&&observed.passed,'Corrected browser check failed; preserve actual output');
 report.passed=true;
}catch(error){report.failure=error.stack;process.exitCode=1;}
finally{
 let observed;try{observed=JSON.parse(fs.readFileSync(path.join(browserOut,'report.json')));report.browser??=observed;}catch{}
 const explicit=observed?.chromeProcessCloseObserved===true&&observed?.chromeClose?.code===0&&observed?.browserServerClosed===true&&observed?.serverCloseObserved===true;
 const stopped=command?.childClosureConfirmed&&command.treeStop?.exitCode===0&&command.treeStop?.error===null;
 closed=command?.childClosureConfirmed&&(explicit||stopped);
 try{report.after=before.map(value=>pin(value.file));assert.deepEqual(report.after,before);report.builtAfter=report.builtBefore.map(value=>pin(value.file));assert.deepEqual(report.builtAfter,report.builtBefore);report.privateAtlasAfter=report.privateAtlasBefore.map(value=>pin(value.file));assert.deepEqual(report.privateAtlasAfter,report.privateAtlasBefore);}catch(error){report.custodyFailure=error.stack;report.passed=false;process.exitCode=1;}
 report.childrenClosed=Boolean(closed);if(closed){assert.equal(JSON.parse(fs.readFileSync(path.join(marker,'owner.json'))).token,token);fs.unlinkSync(path.join(marker,'owner.json'));fs.rmdirSync(marker);report.markerReleased=true;}else report.markerRetained=true;
 report.finishedAt=new Date().toISOString();save();console.log(JSON.stringify({passed:report.passed,cases:report.browser?.cases.length??0,markerReleased:report.markerReleased??false,budgets:report.budgets,failure:report.failure??null}));
}
