# Localized asphalt detail candidate

This small source-derived patch preserves the original aggregate and cracks while excluding the painted stripe, pothole and raised slab rim. It is intended for occasional road-edge wear, with a quiet base between details.

![Asphalt detail](C:/Users/just_/Documents/Codex/2026-09-29/you-are-taking-over-as-lead/outputs/hmh-road47-detail-study-02/asphalt-detail-albedo.png)

- Footprint: 1.75 × 0.75 metres; 224 × 96 pixels; 128 texels/metre.
- Encoded PNG: 42,289 bytes. RGBA decode estimate: 86,016 bytes before mipmaps.
- Original UV-based colour, with a smooth elliptical alpha edge. No source mesh or texture file changed.
- The first crop included raised edge fragments and remains rejected in the preceding study folder.

The corrected crop has been visually reviewed in isolation. Its ground blend, placement, gameplay-scale readability and runtime memory still need checking before it becomes a game asset. It is not a repeating road tile or a new collision surface.
