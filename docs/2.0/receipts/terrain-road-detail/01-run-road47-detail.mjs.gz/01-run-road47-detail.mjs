import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash, randomUUID} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {runOwnedWindowsChild} from './art-a6-owned-native-child.mjs';
const work=fileURLToPath(new URL('.',import.meta.url));
const source='C:/Users/just_/Desktop/Projects/LestersArcade-Assets/Tripo-Level-Design-Batch-2/models/47-47-cracked-asphalt-road-section/model.glb';
const output=path.resolve(work,'../outputs/hmh-road47-detail-study');
const record=path.join(work,'road47-detail-window');
const marker='C:/Users/just_/lesters-arcade-wt/.locks/heavy.lock';
const hash=p=>createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const files=[source,path.join(work,'bake-road47-detail.py'),fileURLToPath(import.meta.url),path.join(work,'art-a6-owned-native-child.mjs')];
const before=Object.fromEntries(files.map(p=>[p,hash(p)]));
assert.equal(before[source],'ba12a806212401d54ad9c545997b95a517e16caf69b7b6532c44cfec7fd35e94');
assert.ok(!fs.existsSync(marker)&&!fs.existsSync(output)&&!fs.existsSync(record));
const token=randomUUID(),report={passed:false,before};
fs.mkdirSync(record);fs.mkdirSync(marker);fs.writeFileSync(path.join(marker,'owner.json'),JSON.stringify({owner:'/root',token,task:'Private road47 localized detail bake'}));
let closed=true;
try{
  closed=false;
  const command=await runOwnedWindowsChild('D:/Apps/Blender/blender.exe',['-b','--threads','2','--factory-startup','--disable-autoexec','--python-exit-code','1','--python',files[1],'--',source,output],{cwd:work,env:{...process.env,PYTHONDONTWRITEBYTECODE:'1',OMP_NUM_THREADS:'2'},watchdogMs:60000});
  report.command=command;closed=command.childClosureConfirmed;
  if(command.spawnedPid){try{process.kill(command.spawnedPid,0);closed=false;}catch(e){if(e.code!=='ESRCH')throw e;report.childAbsent=true;}}
  assert.ok(closed&&command.normalExit);
  report.native=JSON.parse(fs.readFileSync(path.join(output,'report.json')));
  assert.ok(report.native.passed&&report.native.sourceUnchanged);
  report.passed=true;
}catch(error){report.failure=error.stack;process.exitCode=1;}
finally{
  report.after=Object.fromEntries(files.map(p=>[p,hash(p)]));
  try{assert.deepEqual(report.after,before);}catch(error){report.passed=false;report.custodyFailure=error.stack;process.exitCode=1;}
  report.childrenClosed=closed;
  if(closed){assert.equal(JSON.parse(fs.readFileSync(path.join(marker,'owner.json'))).token,token);fs.unlinkSync(path.join(marker,'owner.json'));fs.rmdirSync(marker);report.markerReleased=!fs.existsSync(marker);}
  report.finishedAt=new Date().toISOString();
  fs.writeFileSync(path.join(record,'report.json'),JSON.stringify(report,null,2)+'\n');
  console.log(JSON.stringify({passed:report.passed,closed,markerReleased:report.markerReleased,pid:report.command?.spawnedPid,seconds:report.command?.wholeChildWallMs/1000,failure:report.failure}));
}
