"""Read-only native top views for selecting a source-derived asphalt detail."""
import hashlib
import json
import math
from pathlib import Path
import sys
import bpy
from mathutils import Matrix, Vector

source = Path(sys.argv[sys.argv.index('--') + 1])
out = Path(sys.argv[sys.argv.index('--') + 2])
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
expected = 'ba12a806212401d54ad9c545997b95a517e16caf69b7b6532c44cfec7fd35e94'
assert sha(source) == expected
out.mkdir(exist_ok=False)
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath=str(source))
scene = bpy.context.scene
meshes = [ob for ob in scene.objects if ob.type == 'MESH']
assert len(meshes) == 1
ob = meshes[0]
assert ob.parent is None
bpy.context.view_layer.update()
points = [ob.matrix_world @ Vector(p) for p in ob.bound_box]
low = Vector(tuple(min(p[i] for p in points) for i in range(3)))
high = Vector(tuple(max(p[i] for p in points) for i in range(3)))
scale = 4 / max(high.x-low.x, high.y-low.y)
centre = Vector(((low.x+high.x)/2, (low.y+high.y)/2, low.z))
ob.matrix_world = Matrix.Scale(scale, 4) @ Matrix.Translation(-centre) @ ob.matrix_world
bpy.context.view_layer.update()
geometry_before = [tuple(v.co) for v in ob.data.vertices]
original_materials = list(ob.data.materials)
assert len(original_materials) == 1
camera_data = bpy.data.cameras.new('Road top source inspection')
camera_data.type = 'ORTHO'
camera_data.ortho_scale = 4.24
camera = bpy.data.objects.new(camera_data.name, camera_data)
scene.collection.objects.link(camera)
camera.location = (0, 0, 12)
camera.rotation_euler = (0, 0, 0)
scene.camera = camera
world = bpy.data.worlds.new('Neutral source inspection daylight')
world.use_nodes = True
world.node_tree.nodes['Background'].inputs[0].default_value = (.32, .34, .29, 1)
world.node_tree.nodes['Background'].inputs[1].default_value = .75
scene.world = world
sun = bpy.data.lights.new('Same upper-left key', 'SUN')
sun.energy = 2.1
sun.color = (1, .97, .90)
sun.angle = math.radians(7)
light = bpy.data.objects.new(sun.name, sun)
scene.collection.objects.link(light)
light.location = (-5, -8, 12)
light.rotation_euler = (-light.location).to_track_quat('-Z', 'Y').to_euler()
scene.render.engine = 'CYCLES'
scene.cycles.device = 'CPU'
scene.cycles.samples = 12
scene.cycles.use_adaptive_sampling = False
scene.cycles.use_denoising = False
scene.cycles.max_bounces = 4
scene.render.threads_mode = 'FIXED'
scene.render.threads = 2
scene.render.resolution_x = scene.render.resolution_y = 768
scene.render.resolution_percentage = 100
scene.render.film_transparent = True
scene.render.image_settings.file_format = 'PNG'
scene.render.image_settings.color_mode = 'RGBA'
scene.view_settings.view_transform = 'AgX'
scene.view_settings.exposure = .15
from bpy_extras.object_utils import world_to_camera_view
camera.location = (-.55, .7, 12)
camera.data.ortho_scale = 1.75
scene.render.resolution_x = 224
scene.render.resolution_y = 128
bpy.context.view_layer.update()
# Certify camera coverage, not a resized UV-atlas crop.
for p, expected_pixel in [((-.55-.875, .7+.5, 0), (0, 0)),
                           ((-.55+.875, .7-.5, 0), (224, 128))]:
    uv = world_to_camera_view(scene, camera, Vector(p))
    actual = (uv.x*224, (1-uv.y)*128)
    assert max(abs(a-b) for a,b in zip(actual,expected_pixel)) < 1e-4
albedo = original_materials[0].copy()
nodes, links = albedo.node_tree.nodes, albedo.node_tree.links
bsdf = next(n for n in nodes if n.type == 'BSDF_PRINCIPLED')
colour = bsdf.inputs['Base Color']
assert len(colour.links) == 1
source_socket = colour.links[0].from_socket
output = next(n for n in nodes if n.type == 'OUTPUT_MATERIAL' and n.is_active_output)
emission = nodes.new('ShaderNodeEmission')
links.new(source_socket, emission.inputs['Color'])
space = bpy.data.objects.new('Private road detail mask space', None)
scene.collection.objects.link(space)
space.location = (-.55, .7, 0)
space.scale = (.875, .5, 1)
coord = nodes.new('ShaderNodeTexCoord')
coord.object = space
separate = nodes.new('ShaderNodeSeparateXYZ')
links.new(coord.outputs['Object'], separate.inputs[0])
def math_node(op, a, b=None):
    node = nodes.new('ShaderNodeMath')
    node.operation = op
    links.new(a, node.inputs[0])
    if b is not None:
        links.new(b, node.inputs[1])
    return node.outputs[0]
xx = math_node('MULTIPLY', separate.outputs['X'], separate.outputs['X'])
yy = math_node('MULTIPLY', separate.outputs['Y'], separate.outputs['Y'])
radius = math_node('SQRT', math_node('ADD', xx, yy))
fade = nodes.new('ShaderNodeMapRange')
fade.interpolation_type = 'SMOOTHERSTEP'
fade.clamp = True
links.new(radius, fade.inputs['Value'])
for key, value in [('From Min', .67), ('From Max', 1), ('To Min', 1), ('To Max', 0)]:
    fade.inputs[key].default_value = value
transparent = nodes.new('ShaderNodeBsdfTransparent')
mix = nodes.new('ShaderNodeMixShader')
links.new(fade.outputs['Result'], mix.inputs[0])
links.new(transparent.outputs[0], mix.inputs[1])
links.new(emission.outputs[0], mix.inputs[2])
links.new(mix.outputs[0], output.inputs['Surface'])
ob.data.materials[0] = albedo
scene.view_settings.view_transform = 'Standard'
scene.view_settings.exposure = 0
target = out / 'asphalt-detail-albedo.png'
scene.render.filepath = str(target)
bpy.ops.render.render(write_still=True)
ob.data.materials[0] = original_materials[0]
assert geometry_before == [tuple(v.co) for v in ob.data.vertices]
assert sha(source) == expected
report = {'passed': True, 'sourceUnchanged': True, 'sourceSha256': expected,
          'scope': 'Private UV-preserving 3D source bake; not a runtime asset or tiling terrain texture',
          'image': str(target), 'imageSha256': sha(target), 'imageSize': [224,128],
          'sourceNormalizedHorizontalExtentMetres': 4,
          'cropCentre': [-.55,.7], 'footprintMetres': [1.75,1], 'texelsPerMetre':128,
          'blend': 'smooth elliptical alpha; original aggregate/crack albedo inside',
          'avoidsSourceStripeAndPothole': 'requires original image review',
          'runtimeWritten': False, 'sourceGeometryUnchanged':True}
(out / 'report.json').write_text(json.dumps(report, indent=2)+'\n', encoding='utf8')
