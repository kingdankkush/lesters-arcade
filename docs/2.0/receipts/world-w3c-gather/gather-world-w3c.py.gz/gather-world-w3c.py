from pathlib import Path
import hashlib,json
work=Path(__file__).resolve().parent
repo=Path('C:/Users/just_/lesters-arcade-wt/visual-overhaul-200')
lane=Path('C:/Users/just_/lesters-arcade-wt/200-world-w0')
progress=repo/'docs/2.0/PROGRESS.md';value=progress.read_text(encoding='utf-8')
assert value.count('<<<<<<< HEAD')==value.count('=======')==value.count('>>>>>>> 6c4ae828e (Add isolated local HMH world movement runtime)')==1
value=value.replace('<<<<<<< HEAD\n','').replace('=======\n','\n').replace('>>>>>>> 6c4ae828e (Add isolated local HMH world movement runtime)\n','')
progress.write_text(value,encoding='utf-8',newline='\n')
manifest=json.loads((work/'world-w3c-green-bindings.json').read_text())
sha=lambda raw:hashlib.sha256(raw).hexdigest()
rows=[]
for relative,pin in manifest['sources'].items():
 a=(repo/relative).read_bytes();b=(lane/relative).read_bytes()
 assert sha(b)==pin['sha256'],relative
 assert a.replace(b'\r\n',b'\n')==b.replace(b'\r\n',b'\n'),relative
 rows.append({'path':relative,'rootSha256':sha(a),'testedSha256':sha(b),'rawIdentical':a==b})
differences=[r['path'] for r in rows if not r['rawIdentical']]
assert differences==['apps/hmh-reboot/src/dev/greybox-world-v1.mjs'],differences
for relative,expected in manifest['protectedFiles'].items():assert sha((repo/relative).read_bytes())==expected,relative
report={'schema':'world-w3c-gather/v1','passed':True,'sourceCommit':'6c4ae828e11cace8d36c14f0a64f7d6e9e4b30d5','files':rows,
 'lineEndingOnlyFiles':differences,'protectedFiles':manifest['protectedFiles'],
 'verification':'48 source plus identical isolated48 carried from exact reviewed lane; gathered source equivalent except the previously documented checkout CRLF/LF conversion. No new root execution or browser claim.'}
(work/'world-w3c-root-gather.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'matchedSourceFiles':len(rows),'protectedExact':len(manifest['protectedFiles']),'lineEndingOnly':differences}))
