# River source evidence before browser

Base `bdfa988a4dab1f1304aad116394cd2a3f9e6e105`; own world worktree only.
Seven tests installed before source. Actual RED: seven tests, six expected
missing-layout failures, one exact-road/local-authority control; PID 42172
closed exit 1/no signal.

The first installer copied the author module and added world dispatch, then
stopped while reading the existing syntax list with Python's Windows default
cp1252 codec (`UnicodeDecodeError`, byte 0x9d). No test ran during installation.
The missing two syntax entries were completed using explicit UTF-8; runtime
source was not rewritten or broadened to address this tooling failure.

First GREEN attempt: 99/100, PID 29792, exit 1/no signal. Actual movement stopped
within the test's four-unit target tolerance just before the ramp ended, at
groundZ 0.14146267337687846; the assertion expected 0. The test now returns to
y = area centre + 50, beyond the ramp's dry landing, using the same already
checked corridor. No geometry, elevation, movement or checker fix was needed.
The original report and original test bytes remain in attempt 01.

Final source attempt 02: 100/100 focused and identical 100/100 isolated,
45 exact source/test files without Git/node_modules and with empty PATH.
PIDs 46204, 17780, 10144 (focused/copy/diagnostic) closed exit 0/no signal.
All five source children were independently absent and the exact owned marker
was absent at 2026-09-30T10:45:22.0617199Z.

Global unchanged checker: 36,749/77,589 walkable centres (47.3636727%), 316 more
than Bayou, zero outside. All 98 sites returnable, 14 roads and 57 local paths
pass, including seven River paths. Baron court 217/225 open samples (96.4444%),
both exits and cover heights usable. Gross water plus solid footprint is
1,670,700 square units (water 1,365,000; shelf 184,500; rectangular solids
121,200), below the replaced 2,060,800 allowance. Existing River/Woods nominal
38.172577-second pacing warning remains, not an actual movement timing claim.

No kit/renderer/protected authority changes. Browser walk/framing proof,
owner whole-map playtest, full area art, gameplay/verifier integration,
real-phone performance and release acceptance remain pending.
