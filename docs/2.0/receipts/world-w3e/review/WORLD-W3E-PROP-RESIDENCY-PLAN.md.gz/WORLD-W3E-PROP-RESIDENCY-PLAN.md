# W3e — private world prop display residency

2026-09-30. Parent approved this concrete executable slice. Own world worktree only.

## Audit and corrected scope

The W0 documented gate failure compares incremental navigation patches with a full rebuild for synthetic gates at the outer map border. It is not a measured visible-opening/blocker defect in the V2 private scene. The present V2 authored kit has no dynamic gate kind; Fortress and Pines entrances are gaps between solids whose visible footprints and blockers share the same geometry. No gate/navigation repair is justified by that historical note. Legacy nav remains unchanged.

The real missing capability is residency. Private `world-v2-local-scene.mjs` creates all solid Graphics at startup and only changes visibility per frame. Default `main.mjs` independently loads all prop pages and builds every placement; its optional terrain leases explicitly cover the six legacy districts while props/actors stay pinned. This slice changes the private scene only. It bounds live prop display objects, not asset pages or texture/GPU memory. Ground Graphics, human atlas, geometry, navigation and simulation remain resident.

## Small product change

- Add `src/dev/greybox-prop-residency.mjs`, using the existing static painted-rectangle index. Its detached catalog contains only IDs, area IDs and exact projected paint bounds. No actor, RNG, nav, collision or run hooks enter it.
- Acquire within half a viewport beyond each visible edge; retain already-owned objects within one viewport beyond each edge. Invert the actual camera projection including zoom, ground height and shake. Bounds include tall roofs and every side, so anchor-only culling cannot erase a visible solid.
- Evict/destroy outside the larger boundary before admitting new resources. Repeated stationary frames create nothing. Return traversal recreates released objects once. Exact viewport visibility remains separate from residency.
- Creation callback owns partial construction cleanup. The manager retains ownership through failed destruction and reports the error rather than counting it as freed. Successful disposal is idempotent and prevents future creation; a later disposal retries only retained failed resources, never already released ones. Snapshot exposes detached scalar counts and IDs (catalog/live/peak/created/destroyed/visible/area IDs), never Graphics or world authority.
- Wire the helper into the existing private Pixi scene and preserve its exact solid painter, depth keys, human scale and public controls. Dispose residency before Application teardown. Source has no asynchronous per-prop loads, so pending-init/decode/nav disposal still uses the existing tested scene lifetime; a late successful scene startup cannot allocate props after disposal.

## RED-first coverage

Ten helper cases: lazy catalog admission; exact projected/tall-bound visibility; acquire/retain hysteresis and reversible return; detach/destroy before far admission; catalog/snapshot ownership; disposal and post-disposal updates; callback creation failure cleanup; failed release accounting; malformed input rejection; deterministic order and full authored-world projection coverage. Keep the actual current scene tests and add direct live/evicted/revisited prop ownership plus late disposal coverage with the real helper (only Pixi is substituted). Existing actual movement/nav tests run unchanged. Source and identical isolated-copy tests remain Git-independent.

No helper or renderer behavior is installed before these tests are authored. Initial RED and actual failures are preserved. The focused command, bound source closure and existing owned-child wrapper are frozen before requesting the shared source slot.

## Actual browser checkpoint

Separate private build (30 s) and real Chrome window (120 s), frozen for peer review after source GREEN. Begin in Meadows, walk toward the existing City road and back on keyboard and touch; no injected actor, clock or simulation state. Record resident IDs/live/peak/created/destroyed and capture identical-location before/after terrain and wall context, pause/disposal, desktop and phone proxy. Actual physical phone memory/performance stays unmeasured. Reuse the prior denied-entry and late pagehide checks and preserve every failure. Normal build plus standard `visual:reboot` required in a separate owned window because this is renderer work, with no baseline acceptance.

Art remains greybox. No A18 atlas exists or is claimed. Later production prop/texture streaming needs a separately bound approved asset candidate; this slice supplies actual display lifecycle behavior without inventing a V2 art anchor.
